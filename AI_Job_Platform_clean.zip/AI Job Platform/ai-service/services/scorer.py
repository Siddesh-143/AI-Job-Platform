"""
scorer.py
─────────
Computes the resume-to-job-description match score using two signals:

1. Skill overlap score (60% weight)
   – Ratio of matched skills to total required skills

2. TF-IDF cosine similarity score (40% weight)
   – Measures semantic similarity of the full texts

Final score = weighted average, scaled to 0–100.
Also generates missing-skill gap analysis and improvement suggestions.
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .nlp_analyzer import extract_skills, clean_text


def compute_match_score(resume_text: str, job_description: str, required_skills: str = "") -> dict:
    """
    Analyse a resume against a job description and return a complete
    score report.

    Args:
        resume_text:     Full plain text extracted from the candidate's PDF.
        job_description: The job description + skills required concatenated.

    Returns:
        {
            "match_score":    float (0–100),
            "matched_skills": list[str],
            "missing_skills": list[str],
            "suggestions":    list[str],
        }
    """
    # ── Step 1: Extract skills from both documents ────────────
    resume_skills = set(extract_skills(resume_text))
    jd_skills     = set(extract_skills(job_description))

    # Add explicitly required skills to jd_skills
    if required_skills:
        explicit = [s.strip().title() for s in required_skills.split(',') if s.strip()]
        for es in explicit:
            jd_skills.add(es)

    # Check if explicit jd_skills are mentioned in the resume (even if nlp_analyzer missed them)
    cleaned_resume = resume_text.lower()
    for es in jd_skills:
        if es.lower() in cleaned_resume:
            resume_skills.add(es)

    # ── Step 2: Compute skill overlap ─────────────────────────
    matched_skills = sorted(resume_skills & jd_skills)
    missing_skills = sorted(jd_skills - resume_skills)

    if len(jd_skills) > 0:
        skill_score = len(matched_skills) / len(jd_skills) * 100
    else:
        skill_score = 0.0

    # ── Step 3: TF-IDF cosine similarity ──────────────────────
    cleaned_resume = clean_text(resume_text)
    cleaned_jd     = clean_text(job_description)

    cosine_score = 0.0
    try:
        vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            max_features=5000,
        )
        tfidf_matrix = vectorizer.fit_transform([cleaned_resume, cleaned_jd])
        similarity   = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])
        cosine_score = float(similarity[0][0]) * 100
    except Exception:
        cosine_score = 0.0

    # ── Step 4: Weighted final score ──────────────────────────
    final_score = round((skill_score * 0.60) + (cosine_score * 0.40), 2)
    # Clamp to [0, 100]
    final_score = max(0.0, min(100.0, final_score))

    # ── Step 5: Generate suggestions ─────────────────────────
    suggestions = _generate_suggestions(missing_skills, final_score)

    return {
        "match_score":    final_score,
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "suggestions":    suggestions,
    }


def _generate_suggestions(missing_skills: list[str], score: float) -> list[str]:
    """
    Generate actionable improvement suggestions based on missing skills
    and the overall score.
    """
    suggestions = []

    # Skill-specific suggestions
    for skill in missing_skills[:5]:   # top 5 most important gaps
        suggestions.append(f"Add hands-on experience with {skill} to your resume.")

    # Score-based general suggestions
    if score < 40:
        suggestions.append(
            "Your profile has a low match. Consider tailoring your resume "
            "to highlight skills directly mentioned in the job description."
        )
        suggestions.append(
            "Build 1–2 portfolio projects using the required tech stack "
            "and link them on GitHub."
        )
    elif score < 70:
        suggestions.append(
            "Good foundation! Focus on acquiring the missing skills via "
            "online certifications (Coursera, Udemy, or official vendor certs)."
        )
        suggestions.append(
            "Quantify your achievements (e.g., 'reduced latency by 30%') "
            "to make your resume stand out."
        )
    else:
        suggestions.append(
            "Strong match! Make sure your resume keywords closely mirror "
            "the job description language to pass ATS screening."
        )
        suggestions.append(
            "Prepare detailed STAR-format answers for projects that "
            "demonstrate the matched skills."
        )

    return suggestions
