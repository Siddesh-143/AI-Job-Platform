"""
pdf_parser.py
─────────────
Extracts plain text from an uploaded PDF file using pdfplumber.
Returns the raw concatenated text from all pages.
"""

import io
import pdfplumber


def extract_text_from_pdf(file_bytes: bytes) -> str:
    """
    Extract all text from a PDF given its raw bytes.

    Args:
        file_bytes: Raw bytes of the PDF file.

    Returns:
        A single string containing all extracted text,
        with pages separated by newlines.
    """
    text_parts = []

    with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
        for page_number, page in enumerate(pdf.pages, start=1):
            page_text = page.extract_text()
            if page_text:
                text_parts.append(page_text.strip())

    full_text = "\n\n".join(text_parts)
    return full_text
