"""
nlp_analyzer.py
───────────────
Cleans raw resume/JD text and extracts relevant technical skills
using spaCy NER combined with a curated tech-skills keyword list.
"""

import re
import string
import spacy

# ── Load the spaCy English model ────────────────────────────────────────────
# Run once: python -m spacy download en_core_web_sm
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    # Graceful fallback if model not installed yet
    nlp = None

# ── Curated tech skills master list ─────────────────────────────────────────
# This list is used for fast keyword matching independent of NER.
TECH_SKILLS = {
    # Languages
    "python", "java", "javascript", "typescript", "c++", "c#", "go", "rust",
    "kotlin", "swift", "scala", "r", "php", "ruby", "dart",
    # Frameworks & Libraries
    "spring boot", "spring", "django", "flask", "fastapi", "react", "angular",
    "vue", "node.js", "nodejs", "express", "next.js", "nestjs", "laravel",
    "hibernate", "jpa", "junit", "mockito", "tensorflow", "pytorch", "keras",
    "pandas", "numpy", "scikit-learn", "matplotlib",
    # Databases
    "mysql", "postgresql", "mongodb", "redis", "oracle", "sqlite", "cassandra",
    "dynamodb", "elasticsearch", "neo4j", "mariadb",
    # Cloud & DevOps
    "aws", "azure", "gcp", "docker", "kubernetes", "terraform", "ansible",
    "jenkins", "github actions", "ci/cd", "linux", "nginx", "apache",
    # Big Data
    "hadoop", "spark", "apache spark", "kafka", "airflow", "hive", "flink",
    # Tools & Concepts
    "git", "github", "gitlab", "rest api", "graphql", "microservices",
    "system design", "agile", "scrum", "jira", "machine learning", "deep learning",
    "nlp", "natural language processing", "computer vision", "data science",
    "data engineering", "etl", "data warehouse", "sql", "nosql",
    # Testing
    "selenium", "cypress", "jest", "pytest", "postman",
}


def clean_text(text: str) -> str:
    """
    Normalise raw text:
    - Lowercase
    - Remove URLs
    - Remove excessive whitespace and punctuation
    """
    if not text:
        return ""

    # Lowercase
    text = text.lower()

    # Remove URLs
    text = re.sub(r"http\S+|www\S+", " ", text)

    # Replace non-alphanumeric chars (keep spaces, +, #) with spaces
    text = re.sub(r"[^\w\s+#]", " ", text)

    # Collapse multiple spaces
    text = re.sub(r"\s+", " ", text).strip()

    return text


def extract_skills(text: str) -> list[str]:
    """
    Extract technical skills from cleaned text using two approaches:
    1. Direct keyword matching against the TECH_SKILLS set.
    2. spaCy NER for any PRODUCT / ORG tokens that look like tech terms.

    Returns a deduplicated, sorted list of found skills.
    """
    cleaned = clean_text(text)
    found = set()

    # ── Approach 1: Keyword matching ─────────────────────────
    for skill in TECH_SKILLS:
        # Use word-boundary-aware search
        pattern = r"\b" + re.escape(skill) + r"\b"
        if re.search(pattern, cleaned):
            # Preserve original capitalisation for display
            found.add(skill.title() if len(skill) <= 3 else _canonical(skill))

    # ── Approach 2: spaCy NER ────────────────────────────────
    if nlp is not None:
        doc = nlp(text[:5000])  # limit to first 5000 chars for performance
        for ent in doc.ents:
            if ent.label_ in ("PRODUCT", "ORG", "WORK_OF_ART"):
                token = ent.text.strip().lower()
                if token in TECH_SKILLS:
                    found.add(_canonical(token))

    return sorted(found)


def _canonical(skill: str) -> str:
    """Return a display-friendly version of a skill name."""
    OVERRIDES = {
        "aws": "AWS",
        "gcp": "GCP",
        "sql": "SQL",
        "nosql": "NoSQL",
        "nlp": "NLP",
        "etl": "ETL",
        "ci/cd": "CI/CD",
        "rest api": "REST API",
        "node.js": "Node.js",
        "next.js": "Next.js",
        "apache spark": "Apache Spark",
    }
    return OVERRIDES.get(skill, skill.title())
