"""
main.py — Smart Job Portal AI Microservice
══════════════════════════════════════════
FastAPI application exposing two endpoints:

  POST /parse-pdf  – extract text from an uploaded PDF file
  POST /analyze    – score a resume against a job description

Run with:
  uvicorn main:app --host 0.0.0.0 --port 8000 --reload
"""

import logging
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from services.pdf_parser import extract_text_from_pdf
from services.scorer import compute_match_score

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)
logger = logging.getLogger("ai-service")


# ── Lifespan (startup / shutdown hooks) ──────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🤖 AI microservice starting up …")
    yield
    logger.info("AI microservice shutting down.")


# ── FastAPI App ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="Smart Job Portal — AI Resume Analyzer",
    description=(
        "Microservice that parses PDF resumes and scores them "
        "against job descriptions using NLP and TF-IDF."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

# Allow requests from the Spring Boot backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080", "http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Pydantic Schemas ─────────────────────────────────────────────────────────

class AnalyzeRequest(BaseModel):
    """Request body for the /analyze endpoint."""
    resume_text:     str
    job_description: str
    required_skills: str = ""


class AnalyzeResponse(BaseModel):
    """Response body for the /analyze endpoint."""
    match_score:    float
    matched_skills: list[str]
    missing_skills: list[str]
    suggestions:    list[str]


class ParsePdfResponse(BaseModel):
    """Response body for the /parse-pdf endpoint."""
    text:       str
    char_count: int
    page_count: Optional[int] = None


# ── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/health")
async def health_check():
    """Simple health check — returns 200 OK if the service is running."""
    return {"status": "healthy", "service": "ai-resume-analyzer"}


@app.post("/parse-pdf", response_model=ParsePdfResponse)
async def parse_pdf(file: UploadFile = File(...)):
    """
    Extract plain text from an uploaded PDF file.

    - Accepts multipart/form-data with field name 'file'
    - Returns the extracted text and character count
    """
    # Validate content type
    if file.content_type not in ("application/pdf", "application/octet-stream"):
        raise HTTPException(
            status_code=415,
            detail="Only PDF files are supported (content-type: application/pdf)",
        )

    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")

    try:
        text = extract_text_from_pdf(file_bytes)
    except Exception as e:
        logger.error("PDF parsing failed: %s", str(e))
        raise HTTPException(status_code=422, detail=f"Failed to parse PDF: {str(e)}")

    logger.info("Parsed PDF '%s' → %d chars", file.filename, len(text))
    return ParsePdfResponse(text=text, char_count=len(text))


@app.post("/analyze", response_model=AnalyzeResponse)
async def analyze_resume(request: AnalyzeRequest):
    """
    Score a resume against a job description.

    Scoring pipeline:
      1. Extract skills from both texts (spaCy + keyword list)
      2. Compute skill overlap score  (60% weight)
      3. Compute TF-IDF cosine sim   (40% weight)
      4. Generate improvement suggestions

    Returns a score 0–100, matched/missing skills, and suggestions.
    """
    if not request.resume_text.strip():
        raise HTTPException(status_code=400, detail="resume_text cannot be empty")
    if not request.job_description.strip():
        raise HTTPException(status_code=400, detail="job_description cannot be empty")

    try:
        result = compute_match_score(
            resume_text=request.resume_text,
            job_description=request.job_description,
            required_skills=request.required_skills,
        )
    except Exception as e:
        logger.error("Scoring failed: %s", str(e))
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

    logger.info(
        "Analysis complete — score=%.2f matched=%d missing=%d",
        result["match_score"],
        len(result["matched_skills"]),
        len(result["missing_skills"]),
    )
    return AnalyzeResponse(**result)
