package com.jobportal.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response payload for GET /api/admin/analytics
 * Provides key system-wide statistics for the Admin dashboard.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnalyticsResponse {
    private long totalUsers;
    private long totalRecruiters;
    private long totalCandidates;
    private long totalJobs;
    private long openJobs;
    private long closedJobs;
    private long totalApplications;
    private long pendingApplications;
    private long shortlistedApplications;
    private long rejectedApplications;
}
