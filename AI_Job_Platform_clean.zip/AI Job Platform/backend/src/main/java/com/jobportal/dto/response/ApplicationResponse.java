package com.jobportal.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Response payload for application listing and detail endpoints.
 * Includes embedded AI score details so the frontend can render them in one request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationResponse {
    private Long           id;

    // ── Candidate info ──────────────────────────────────────
    private Long           candidateId;
    private String         candidateName;
    private String         candidateEmail;

    // ── Job info ────────────────────────────────────────────
    private Long           jobId;
    private String         jobTitle;
    private String         company;

    // ── Application metadata ────────────────────────────────
    private String         status;
    private String         coverLetter;
    private LocalDateTime  appliedAt;

    // ── AI Score (may be null if not yet analysed) ──────────
    private AiScoreResponse aiScore;
}
