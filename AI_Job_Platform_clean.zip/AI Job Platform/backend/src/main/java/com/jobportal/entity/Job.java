package com.jobportal.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * JPA Entity representing a job posting.
 * Linked to a recruiter (User) and can have many Applications.
 */
@Entity
@Table(name = "jobs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false, length = 150)
    private String company;

    @Column(length = 100)
    private String location;

    @Column(name = "salary_range", length = 50)
    private String salaryRange;

    /**
     * Comma-separated list of required skills.
     * e.g. "Java,Spring Boot,MySQL,Docker"
     * Used by the AI module for keyword matching.
     */
    @Column(name = "skills_required", columnDefinition = "TEXT")
    private String skillsRequired;

    @Column(name = "experience_years", length = 30)
    private String experienceYears;

    @Column(name = "job_type", length = 20)
    @Builder.Default
    private String jobType = "FULL_TIME";

    /** OPEN or CLOSED */
    @Column(nullable = false, length = 10)
    @Builder.Default
    private String status = "OPEN";

    // ── Relationships ───────────────────────────────────────

    /** Recruiter who posted this job */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recruiter_id", nullable = false)
    private User recruiter;

    /** All applications submitted for this job */
    @OneToMany(mappedBy = "job", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Application> applications;

    // ── JPA Lifecycle Callbacks ─────────────────────────────

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt  = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
