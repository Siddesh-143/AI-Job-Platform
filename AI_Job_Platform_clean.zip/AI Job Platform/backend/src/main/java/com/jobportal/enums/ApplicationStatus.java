package com.jobportal.enums;

/**
 * Lifecycle states for a job application.
 * PENDING     - Application submitted, awaiting recruiter review
 * SHORTLISTED - Recruiter marked candidate as shortlisted
 * REJECTED    - Application was rejected
 */
public enum ApplicationStatus {
    PENDING,
    SHORTLISTED,
    REJECTED
}
