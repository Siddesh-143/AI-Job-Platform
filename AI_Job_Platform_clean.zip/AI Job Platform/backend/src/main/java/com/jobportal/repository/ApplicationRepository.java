package com.jobportal.repository;

import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.enums.ApplicationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for Application entity.
 */
@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {

    /** All applications by a specific candidate */
    List<Application> findByCandidateId(Long candidateId);

    /** All applications for a specific job (for recruiter dashboard) */
    List<Application> findByJobId(Long jobId);

    /** Check if candidate already applied to a job (prevents duplicate applications) */
    boolean existsByCandidateAndJob(User candidate, Job job);

    /** Find a specific application by candidate + job (for status checks) */
    Optional<Application> findByCandidateAndJob(User candidate, Job job);

    /** Applications by status (Admin analytics) */
    List<Application> findByStatus(ApplicationStatus status);

    /** Count total applications */
    long count();

    /** Count applications per status (Admin analytics) */
    long countByStatus(ApplicationStatus status);
}
