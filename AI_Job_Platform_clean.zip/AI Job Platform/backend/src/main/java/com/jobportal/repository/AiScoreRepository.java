package com.jobportal.repository;

import com.jobportal.entity.AiScore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Spring Data JPA repository for AiScore entity.
 */
@Repository
public interface AiScoreRepository extends JpaRepository<AiScore, Long> {

    /** Find AI score for a specific application */
    Optional<AiScore> findByApplicationId(Long applicationId);

    /** Check if an application already has an AI score */
    boolean existsByApplicationId(Long applicationId);
}
