package com.jobportal.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Response payload for user listing (Admin panel).
 * Excludes sensitive fields like password.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserResponse {
    private Long          id;
    private String        name;
    private String        email;
    private String        role;
    private boolean       isActive;
    private LocalDateTime createdAt;
}
