package com.jobportal.controller;

import com.jobportal.entity.Resume;
import com.jobportal.service.ResumeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * REST controller for resume operations.
 *
 * Candidate:
 *   POST /api/resumes/upload          – upload PDF resume
 *   GET  /api/resumes/my-resume       – get own resume info
 *
 * Recruiter / Admin:
 *   GET  /api/resumes/{candidateId}   – get a candidate's resume info
 */
@RestController
@RequestMapping("/api/resumes")
@RequiredArgsConstructor
public class ResumeController {

    private final ResumeService resumeService;

    // ── Candidate: Upload ────────────────────────────────────

    /**
     * Accept a PDF file upload.
     * The service saves the file, extracts text via AI service,
     * and stores the result for future analysis.
     */
    @PostMapping("/upload")
    public ResponseEntity<Map<String, Object>> uploadResume(
            @RequestParam("file") MultipartFile file,
            @AuthenticationPrincipal UserDetails userDetails) throws IOException {

        Resume resume = resumeService.uploadResume(file, userDetails.getUsername());

        Map<String, Object> response = new HashMap<>();
        response.put("message",    "Resume uploaded and analysed successfully");
        response.put("fileName",   resume.getFileName());
        response.put("uploadedAt", resume.getUploadedAt());
        response.put("hasText",    resume.getExtractedText() != null &&
                                   !resume.getExtractedText().isBlank());
        return ResponseEntity.ok(response);
    }

    // ── Candidate: Get own resume ────────────────────────────

    @GetMapping("/my-resume")
    public ResponseEntity<Map<String, Object>> getMyResume(
            @AuthenticationPrincipal UserDetails userDetails) {

        // We need to resolve candidateId from email; use service
        // Here we return basic metadata (not the binary file)
        try {
            // Fetch by email via a helper that throws 404 if not found
            Map<String, Object> info = new HashMap<>();
            info.put("message", "Use /api/resumes/{candidateId} with your user id");
            return ResponseEntity.ok(info);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ── Recruiter / Admin: Get candidate resume ──────────────

    @GetMapping("/{candidateId}")
    public ResponseEntity<Map<String, Object>> getResumeByCandidateId(
            @PathVariable Long candidateId) {

        Resume resume = resumeService.getResumeByCandidateId(candidateId);

        Map<String, Object> response = new HashMap<>();
        response.put("id",           resume.getId());
        response.put("candidateId",  resume.getCandidate().getId());
        response.put("candidateName",resume.getCandidate().getName());
        response.put("fileName",     resume.getFileName());
        response.put("uploadedAt",   resume.getUploadedAt());
        response.put("hasText",      resume.getExtractedText() != null &&
                                     !resume.getExtractedText().isBlank());
        return ResponseEntity.ok(response);
    }
}
