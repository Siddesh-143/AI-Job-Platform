package com.jobportal.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * Request body for PUT /api/applications/{id}/status
 * Allows a recruiter to update an application's status.
 */
@Data
public class ApplicationStatusRequest {

    @NotBlank(message = "Status is required")
    @Pattern(regexp = "PENDING|SHORTLISTED|REJECTED",
             message = "Status must be PENDING, SHORTLISTED, or REJECTED")
    private String status;
}
