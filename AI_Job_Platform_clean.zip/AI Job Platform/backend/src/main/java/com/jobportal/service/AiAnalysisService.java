package com.jobportal.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jobportal.dto.response.AiScoreResponse;
import com.jobportal.entity.AiScore;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Service responsible for calling the Python FastAPI AI microservice
 * and persisting the analysis results as AiScore entities.
 *
 * The AI service endpoint: POST http://localhost:8000/analyze
 * Request body:  { "resume_text": "...", "job_description": "..." }
 * Response body: { "match_score": 82.5, "matched_skills": [...], ... }
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AiAnalysisService {

    private final RestTemplate  restTemplate;
    private final ObjectMapper  objectMapper;

    @Value("${ai.service.url}")
    private String aiServiceUrl;

    /**
     * Call the AI microservice to analyze a resume against a job description.
     *
     * @param resumeText     Full plain text extracted from the candidate's PDF
     * @param jobDescription The job's description + skills_required concatenated
     * @return AiScore entity (not yet persisted — caller must save it)
     */
    public AiScore analyzeResume(String resumeText, String jobDescription, String skillsRequired) {
        String endpoint = aiServiceUrl + "/analyze";

        // Build request body
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("resume_text",      resumeText);
        requestBody.put("job_description",  jobDescription);
        requestBody.put("required_skills",  skillsRequired != null ? skillsRequired : "");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<Map> response = restTemplate.postForEntity(
                endpoint, request, Map.class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                Map<String, Object> body = response.getBody();

                double matchScore = ((Number) body.getOrDefault("match_score", 0.0)).doubleValue();
                String matchedSkillsJson = toJson(body.get("matched_skills"));
                String missingSkillsJson = toJson(body.get("missing_skills"));
                String suggestionsJson   = toJson(body.get("suggestions"));

                return AiScore.builder()
                    .matchScore(matchScore)
                    .matchedSkills(matchedSkillsJson)
                    .missingSkills(missingSkillsJson)
                    .suggestions(suggestionsJson)
                    .analyzedAt(LocalDateTime.now())
                    .build();
            }
        } catch (Exception ex) {
            log.error("AI service call failed: {}. Returning default score.", ex.getMessage());
        }

        // Fallback: return a zero score if the AI service is unavailable
        return AiScore.builder()
            .matchScore(0.0)
            .matchedSkills("[]")
            .missingSkills("[]")
            .suggestions("[\"AI service is currently unavailable. Please try again later.\"]")
            .analyzedAt(LocalDateTime.now())
            .build();
    }

    /**
     * Convert an AiScore entity to its DTO representation.
     * Parses the stored JSON strings back into typed lists.
     */
    public AiScoreResponse toResponse(AiScore score) {
        return AiScoreResponse.builder()
            .id(score.getId())
            .applicationId(score.getApplication() != null
                ? score.getApplication().getId() : null)
            .matchScore(score.getMatchScore())
            .matchedSkills(parseJsonList(score.getMatchedSkills()))
            .missingSkills(parseJsonList(score.getMissingSkills()))
            .suggestions(parseJsonList(score.getSuggestions()))
            .analyzedAt(score.getAnalyzedAt())
            .build();
    }

    // ── Private Helpers ──────────────────────────────────────

    private String toJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            return "[]";
        }
    }

    private List<String> parseJsonList(String json) {
        if (json == null || json.isBlank()) return Collections.emptyList();
        try {
            return objectMapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }
}
