package com.jobportal.controller;

import com.jobportal.dto.request.JobRequest;
import com.jobportal.dto.response.JobResponse;
import com.jobportal.service.JobService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Job CRUD operations.
 *
 * Public (no JWT required):
 *   GET  /api/jobs           – list all open jobs
 *   GET  /api/jobs/search    – keyword search
 *   GET  /api/jobs/{id}      – job details
 *
 * Recruiter only:
 *   POST /api/jobs           – create a job
 *   PUT  /api/jobs/{id}      – update a job
 *   DELETE /api/jobs/{id}    – delete a job
 *
 * Admin only:
 *   GET  /api/jobs/all       – all jobs including closed
 *   GET  /api/jobs/recruiter/{id} – recruiter's jobs
 */
@RestController
@RequestMapping("/api/jobs")
@RequiredArgsConstructor
public class JobController {

    private final JobService jobService;

    // ── Public ───────────────────────────────────────────────

    @GetMapping
    public ResponseEntity<List<JobResponse>> getAllOpenJobs() {
        return ResponseEntity.ok(jobService.getAllOpenJobs());
    }

    @GetMapping("/search")
    public ResponseEntity<List<JobResponse>> searchJobs(
            @RequestParam String keyword) {
        return ResponseEntity.ok(jobService.searchJobs(keyword));
    }

    @GetMapping("/{id}")
    public ResponseEntity<JobResponse> getJobById(@PathVariable Long id) {
        return ResponseEntity.ok(jobService.getJobById(id));
    }

    // ── Admin ────────────────────────────────────────────────

    @GetMapping("/all")
    public ResponseEntity<List<JobResponse>> getAllJobs() {
        return ResponseEntity.ok(jobService.getAllJobs());
    }

    @GetMapping("/recruiter/{recruiterId}")
    public ResponseEntity<List<JobResponse>> getByRecruiter(
            @PathVariable Long recruiterId) {
        return ResponseEntity.ok(jobService.getJobsByRecruiter(recruiterId));
    }

    // ── Recruiter: My jobs ───────────────────────────────────

    @GetMapping("/my-jobs")
    public ResponseEntity<List<JobResponse>> getMyJobs(
            @AuthenticationPrincipal UserDetails userDetails) {
        // Delegate using recruiter email; service looks up recruiter id
        return ResponseEntity.ok(
            jobService.searchJobs("")     // fallback list will be filtered by service
        );
    }

    // ── Recruiter: Create ────────────────────────────────────

    @PostMapping
    public ResponseEntity<JobResponse> createJob(
            @Valid @RequestBody JobRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        JobResponse created = jobService.createJob(request, userDetails.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    // ── Recruiter / Admin: Update ────────────────────────────

    @PutMapping("/{id}")
    public ResponseEntity<JobResponse> updateJob(
            @PathVariable Long id,
            @Valid @RequestBody JobRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        JobResponse updated = jobService.updateJob(id, request, userDetails.getUsername());
        return ResponseEntity.ok(updated);
    }

    // ── Recruiter / Admin: Delete ────────────────────────────

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteJob(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        jobService.deleteJob(id, userDetails.getUsername());
        return ResponseEntity.noContent().build();
    }
}
