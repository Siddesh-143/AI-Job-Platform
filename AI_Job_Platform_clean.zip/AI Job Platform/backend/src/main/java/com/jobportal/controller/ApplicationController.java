package com.jobportal.controller;

import com.jobportal.dto.request.ApplicationStatusRequest;
import com.jobportal.dto.response.ApplicationResponse;
import com.jobportal.service.ApplicationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for job applications.
 *
 * Candidate:
 *   POST /api/applications/apply/{jobId}   – apply for a job (triggers AI)
 *   GET  /api/applications/my-applications – view own applications
 *
 * Recruiter:
 *   GET  /api/applications/job/{jobId}     – applicants for a job
 *   PUT  /api/applications/{id}/status     – shortlist / reject
 */
@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
public class ApplicationController {

    private final ApplicationService applicationService;

    // ── Candidate: Apply ─────────────────────────────────────

    @PostMapping(value = "/apply/{jobId}", consumes = {"multipart/form-data"})
    public ResponseEntity<ApplicationResponse> apply(
            @PathVariable Long jobId,
            @RequestParam(required = false, defaultValue = "") String coverLetter,
            @RequestParam(required = false) org.springframework.web.multipart.MultipartFile resumeFile,
            @AuthenticationPrincipal UserDetails userDetails) {

        ApplicationResponse response =
            applicationService.applyForJob(jobId, userDetails.getUsername(), coverLetter, resumeFile);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // ── Candidate: My applications ───────────────────────────

    @GetMapping("/my-applications")
    public ResponseEntity<List<ApplicationResponse>> getMyApplications(
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(
            applicationService.getMyApplications(userDetails.getUsername())
        );
    }

    // ── Recruiter: Applicants for a job ──────────────────────

    @GetMapping("/job/{jobId}")
    public ResponseEntity<List<ApplicationResponse>> getApplicationsForJob(
            @PathVariable Long jobId) {
        return ResponseEntity.ok(applicationService.getApplicationsForJob(jobId));
    }

    // ── Recruiter: Update status ─────────────────────────────

    @PutMapping("/{id}/status")
    public ResponseEntity<ApplicationResponse> updateStatus(
            @PathVariable Long id,
            @Valid @RequestBody ApplicationStatusRequest request) {
        return ResponseEntity.ok(applicationService.updateStatus(id, request));
    }
}
