package com.jobportal.repository;

import com.jobportal.entity.Resume;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Spring Data JPA repository for Resume entity.
 */
@Repository
public interface ResumeRepository extends JpaRepository<Resume, Long> {

    /** Find a candidate's resume by their user id */
    Optional<Resume> findByCandidateId(Long candidateId);

    /** Check if a candidate has already uploaded a resume */
    boolean existsByCandidateId(Long candidateId);
}
