package com.jobportal.service;

import com.jobportal.config.JwtTokenProvider;
import com.jobportal.dto.request.LoginRequest;
import com.jobportal.dto.request.RegisterRequest;
import com.jobportal.dto.response.AuthResponse;
import com.jobportal.dto.response.UserResponse;
import com.jobportal.entity.User;
import com.jobportal.enums.Role;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Handles user registration, authentication, and profile retrieval.
 * Also implements UserDetailsService so Spring Security can load users by email.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository        userRepository;
    private final PasswordEncoder       passwordEncoder;
    private final JwtTokenProvider      jwtTokenProvider;
    private final AuthenticationManager authenticationManager;

    // ── Registration ────────────────────────────────────────

    /**
     * Register a new user. Only CANDIDATE and RECRUITER roles are allowed
     * via the public API (ADMIN must be seeded directly in the DB).
     */
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        // Ensure email is unique
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalStateException("Email address is already registered: " + request.getEmail());
        }

        // Build and persist the new user
        User user = User.builder()
            .name(request.getName())
            .email(request.getEmail())
            .password(passwordEncoder.encode(request.getPassword()))
            .role(Role.valueOf(request.getRole()))
            .isActive(true)
            .build();

        userRepository.save(user);
        log.info("New user registered: {} ({})", user.getEmail(), user.getRole());

        // Generate JWT and return auth payload
        String token = jwtTokenProvider.generateToken(user.getEmail());
        return buildAuthResponse(token, user);
    }

    // ── Login ────────────────────────────────────────────────

    /**
     * Authenticate with email + password and return a JWT.
     */
    public AuthResponse login(LoginRequest request) {
        // Delegate to Spring Security — throws BadCredentialsException on failure
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user  = (User) authentication.getPrincipal();
        String jwt = jwtTokenProvider.generateToken(authentication);

        log.info("User logged in: {}", user.getEmail());
        return buildAuthResponse(jwt, user);
    }

    // ── Profile ──────────────────────────────────────────────

    /**
     * Return the current user's profile (no password).
     */
    public UserResponse getCurrentUser(String email) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
        return toUserResponse(user);
    }

    // ── Private Helpers ──────────────────────────────────────

    private AuthResponse buildAuthResponse(String token, User user) {
        return AuthResponse.builder()
            .token(token)
            .type("Bearer")
            .id(user.getId())
            .name(user.getName())
            .email(user.getEmail())
            .role(user.getRole().name())
            .build();
    }

    private UserResponse toUserResponse(User user) {
        return UserResponse.builder()
            .id(user.getId())
            .name(user.getName())
            .email(user.getEmail())
            .role(user.getRole().name())
            .isActive(user.isActive())
            .createdAt(user.getCreatedAt())
            .build();
    }
}
