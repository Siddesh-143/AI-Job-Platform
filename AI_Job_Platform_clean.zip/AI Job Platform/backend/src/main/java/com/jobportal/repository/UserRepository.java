package com.jobportal.repository;

import com.jobportal.entity.User;
import com.jobportal.enums.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for User entity.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /** Find a user by email (used for Spring Security authentication) */
    Optional<User> findByEmail(String email);

    /** Check if an email is already registered */
    boolean existsByEmail(String email);

    /** Fetch all users with a specific role (Admin use) */
    List<User> findByRole(Role role);

    /** Fetch all active/inactive users */
    List<User> findByIsActive(boolean isActive);

    /** Count users by role (Admin analytics) */
    long countByRole(Role role);
}
