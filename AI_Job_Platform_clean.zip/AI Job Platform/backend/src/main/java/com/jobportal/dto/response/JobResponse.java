package com.jobportal.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Response payload for job listing and detail endpoints.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JobResponse {
    private Long          id;
    private String        title;
    private String        description;
    private String        company;
    private String        location;
    private String        salaryRange;
    private String        skillsRequired;
    private String        experienceYears;
    private String        jobType;
    private String        status;
    private Long          recruiterId;
    private String        recruiterName;
    private int           applicationCount;
    private LocalDateTime createdAt;
}
