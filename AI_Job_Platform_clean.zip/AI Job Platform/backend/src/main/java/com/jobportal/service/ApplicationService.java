package com.jobportal.service;

import com.jobportal.dto.request.ApplicationStatusRequest;
import com.jobportal.dto.response.ApplicationResponse;
import com.jobportal.dto.response.AiScoreResponse;
import com.jobportal.entity.*;
import com.jobportal.enums.ApplicationStatus;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Handles job application lifecycle:
 * - Candidate applies for a job (triggers AI analysis)
 * - Recruiter updates application status
 * - Listing applications for candidate/recruiter
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final JobRepository         jobRepository;
    private final UserRepository        userRepository;
    private final ResumeRepository      resumeRepository;
    private final AiScoreRepository     aiScoreRepository;
    private final AiAnalysisService     aiAnalysisService;
    private final ResumeService         resumeService;

    // ── Candidate: Apply for a job ────────────────────────────

    /**
     * Candidate applies for a job.
     * Triggers AI analysis if a resume is uploaded.
     */
    @Transactional
    public ApplicationResponse applyForJob(Long jobId, String candidateEmail, String coverLetter, org.springframework.web.multipart.MultipartFile resumeFile) {
        User candidate = findUserOrThrow(candidateEmail);
        Job  job       = findJobOrThrow(jobId);

        // Validate job is still open
        if (!"OPEN".equals(job.getStatus())) {
            throw new IllegalStateException("This job is no longer accepting applications");
        }

        // Prevent duplicate applications
        if (applicationRepository.existsByCandidateAndJob(candidate, job)) {
            throw new IllegalStateException("You have already applied for this job");
        }

        // Create application
        Application application = Application.builder()
            .candidate(candidate)
            .job(job)
            .status(ApplicationStatus.PENDING)
            .coverLetter(coverLetter)
            .build();

        application = applicationRepository.save(application);

        // Determine which resume text to use
        String extractedText = null;
        String fileName = null;
        
        if (resumeFile != null && !resumeFile.isEmpty()) {
            extractedText = resumeService.extractTextFromPdf(resumeFile);
            fileName = resumeFile.getOriginalFilename();
        } else {
            Resume resume = resumeRepository.findByCandidateId(candidate.getId()).orElse(null);
            if (resume != null) {
                extractedText = resume.getExtractedText();
                fileName = resume.getFileName();
            }
        }
        
        application.setResumeText(extractedText);
        application.setResumeFileName(fileName);

        // Trigger AI analysis if text is available
        if (extractedText != null && !extractedText.isBlank()) {
            String jobText = job.getDescription() + " " + job.getSkillsRequired();
            AiScore score  = aiAnalysisService.analyzeResume(extractedText, jobText, job.getSkillsRequired());
            score.setApplication(application);
            aiScoreRepository.save(score);
            application.setAiScore(score);
            log.info("AI analysis complete for application id={}, score={}",
                     application.getId(), score.getMatchScore());
        } else {
            log.warn("No resume text found for candidate {}; skipping AI analysis", candidateEmail);
        }

        return toResponse(application);
    }

    // ── Candidate: View own applications ─────────────────────

    @Transactional(readOnly = true)
    public List<ApplicationResponse> getMyApplications(String candidateEmail) {
        User candidate = findUserOrThrow(candidateEmail);
        return applicationRepository.findByCandidateId(candidate.getId())
            .stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    // ── Recruiter: View applicants for a job ─────────────────

    @Transactional(readOnly = true)
    public List<ApplicationResponse> getApplicationsForJob(Long jobId) {
        return applicationRepository.findByJobId(jobId)
            .stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    // ── Recruiter: Update application status ─────────────────

    @Transactional
    public ApplicationResponse updateStatus(Long applicationId, ApplicationStatusRequest request) {
        Application application = applicationRepository.findById(applicationId)
            .orElseThrow(() -> new ResourceNotFoundException("Application", "id", applicationId));

        application.setStatus(ApplicationStatus.valueOf(request.getStatus()));
        return toResponse(applicationRepository.save(application));
    }

    // ── Private Helpers ──────────────────────────────────────

    private User findUserOrThrow(String email) {
        return userRepository.findByEmail(email)
            .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
    }

    private Job findJobOrThrow(Long jobId) {
        return jobRepository.findById(jobId)
            .orElseThrow(() -> new ResourceNotFoundException("Job", "id", jobId));
    }

    public ApplicationResponse toResponse(Application app) {
        AiScoreResponse scoreDto = null;
        if (app.getAiScore() != null) {
            scoreDto = aiAnalysisService.toResponse(app.getAiScore());
        }

        return ApplicationResponse.builder()
            .id(app.getId())
            .candidateId(app.getCandidate().getId())
            .candidateName(app.getCandidate().getName())
            .candidateEmail(app.getCandidate().getEmail())
            .jobId(app.getJob().getId())
            .jobTitle(app.getJob().getTitle())
            .company(app.getJob().getCompany())
            .status(app.getStatus().name())
            .coverLetter(app.getCoverLetter())
            .appliedAt(app.getAppliedAt())
            .aiScore(scoreDto)
            .build();
    }
}
