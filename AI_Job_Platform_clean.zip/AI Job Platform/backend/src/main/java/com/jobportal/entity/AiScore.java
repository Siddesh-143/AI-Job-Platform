package com.jobportal.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * JPA Entity storing the AI analysis result for a specific application.
 * OneToOne with Application.
 *
 * matchedSkills / missingSkills / suggestions are stored as JSON strings
 * (e.g., '["Java","Spring Boot"]') for simple portability.
 */
@Entity
@Table(name = "ai_scores")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AiScore {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** The application this score belongs to */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id", nullable = false, unique = true)
    private Application application;

    /** Overall match score between 0 and 100 */
    @Column(name = "match_score")
    private Double matchScore;

    /** JSON array of skills found in both resume and JD — e.g. ["Java","SQL"] */
    @Column(name = "matched_skills", columnDefinition = "TEXT")
    private String matchedSkills;

    /** JSON array of skills in JD but missing from resume */
    @Column(name = "missing_skills", columnDefinition = "TEXT")
    private String missingSkills;

    /** JSON array of actionable improvement suggestions */
    @Column(name = "suggestions", columnDefinition = "TEXT")
    private String suggestions;

    @Column(name = "analyzed_at", nullable = false)
    private LocalDateTime analyzedAt;

    @PrePersist
    protected void onCreate() {
        analyzedAt = LocalDateTime.now();
    }
}
