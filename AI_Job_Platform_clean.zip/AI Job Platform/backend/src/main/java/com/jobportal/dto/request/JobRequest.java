package com.jobportal.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * Request body for POST /api/jobs (create) and PUT /api/jobs/{id} (update).
 */
@Data
public class JobRequest {

    @NotBlank(message = "Job title is required")
    private String title;

    @NotBlank(message = "Job description is required")
    private String description;

    @NotBlank(message = "Company name is required")
    private String company;

    private String location;

    private String salaryRange;

    /**
     * Comma-separated skills used by AI matcher.
     * e.g. "Java,Spring Boot,MySQL,Docker"
     */
    @NotBlank(message = "Skills required field cannot be empty")
    private String skillsRequired;

    private String experienceYears;

    /** FULL_TIME | PART_TIME | CONTRACT | INTERNSHIP */
    private String jobType;

    /** OPEN | CLOSED (defaults to OPEN on creation) */
    private String status;
}
