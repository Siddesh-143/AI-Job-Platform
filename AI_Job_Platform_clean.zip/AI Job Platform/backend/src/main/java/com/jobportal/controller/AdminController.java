package com.jobportal.controller;

import com.jobportal.dto.response.AnalyticsResponse;
import com.jobportal.dto.response.UserResponse;
import com.jobportal.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST controller for Admin-only operations.
 * All endpoints require ROLE_ADMIN (enforced via SecurityConfig + @PreAuthorize).
 *
 *   GET    /api/admin/users            – list all users
 *   PUT    /api/admin/users/{id}/block – block/unblock a user
 *   DELETE /api/admin/users/{id}       – delete a user
 *   GET    /api/admin/analytics        – system statistics
 */
@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final AdminService adminService;

    // ── User Management ──────────────────────────────────────

    @GetMapping("/users")
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        return ResponseEntity.ok(adminService.getAllUsers());
    }

    /**
     * Toggle the active/blocked status of a user.
     * Returns the updated user record so the frontend can reflect the change immediately.
     */
    @PutMapping("/users/{id}/block")
    public ResponseEntity<UserResponse> toggleUserStatus(@PathVariable Long id) {
        return ResponseEntity.ok(adminService.toggleUserStatus(id));
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable Long id) {
        adminService.deleteUser(id);
        return ResponseEntity.ok(Map.of("message", "User deleted successfully"));
    }

    // ── Analytics ────────────────────────────────────────────

    @GetMapping("/analytics")
    public ResponseEntity<AnalyticsResponse> getAnalytics() {
        return ResponseEntity.ok(adminService.getAnalytics());
    }
}
