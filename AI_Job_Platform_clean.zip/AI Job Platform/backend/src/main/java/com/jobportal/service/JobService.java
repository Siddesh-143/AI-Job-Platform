package com.jobportal.service;

import com.jobportal.dto.request.JobRequest;
import com.jobportal.dto.response.JobResponse;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Business logic for job CRUD operations.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class JobService {

    private final JobRepository  jobRepository;
    private final UserRepository userRepository;

    // ── Public ───────────────────────────────────────────────

    /** Return all open jobs (for candidate job listing page) */
    @Transactional(readOnly = true)
    public List<JobResponse> getAllOpenJobs() {
        return jobRepository.findByStatus("OPEN")
            .stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    /** Return all jobs regardless of status (Admin) */
    @Transactional(readOnly = true)
    public List<JobResponse> getAllJobs() {
        return jobRepository.findAll()
            .stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    /** Full-text search across title, company, location */
    @Transactional(readOnly = true)
    public List<JobResponse> searchJobs(String keyword) {
        return jobRepository.searchJobs(keyword)
            .stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    /** Get a single job by ID */
    @Transactional(readOnly = true)
    public JobResponse getJobById(Long jobId) {
        Job job = findJobOrThrow(jobId);
        return toResponse(job);
    }

    /** Return all jobs posted by a specific recruiter */
    @Transactional(readOnly = true)
    public List<JobResponse> getJobsByRecruiter(Long recruiterId) {
        return jobRepository.findByRecruiterId(recruiterId)
            .stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    // ── Recruiter CRUD ───────────────────────────────────────

    /** Post a new job */
    @Transactional
    public JobResponse createJob(JobRequest request, String recruiterEmail) {
        User recruiter = findUserOrThrow(recruiterEmail);

        Job job = Job.builder()
            .title(request.getTitle())
            .description(request.getDescription())
            .company(request.getCompany())
            .location(request.getLocation())
            .salaryRange(request.getSalaryRange())
            .skillsRequired(request.getSkillsRequired())
            .experienceYears(request.getExperienceYears())
            .jobType(request.getJobType() != null ? request.getJobType() : "FULL_TIME")
            .status("OPEN")
            .recruiter(recruiter)
            .build();

        Job saved = jobRepository.save(job);
        log.info("Job created: '{}' by {}", saved.getTitle(), recruiterEmail);
        return toResponse(saved);
    }

    /** Update an existing job */
    @Transactional
    public JobResponse updateJob(Long jobId, JobRequest request, String recruiterEmail) {
        Job job = findJobOrThrow(jobId);

        // Ensure the recruiter owns this job (unless Admin)
        User caller = findUserOrThrow(recruiterEmail);
        if (!job.getRecruiter().getId().equals(caller.getId()) &&
            !caller.getRole().name().equals("ADMIN")) {
            throw new IllegalStateException("You are not authorised to update this job");
        }

        job.setTitle(request.getTitle());
        job.setDescription(request.getDescription());
        job.setCompany(request.getCompany());
        job.setLocation(request.getLocation());
        job.setSalaryRange(request.getSalaryRange());
        job.setSkillsRequired(request.getSkillsRequired());
        job.setExperienceYears(request.getExperienceYears());
        if (request.getJobType() != null) job.setJobType(request.getJobType());
        if (request.getStatus()  != null) job.setStatus(request.getStatus());

        return toResponse(jobRepository.save(job));
    }

    /** Delete a job */
    @Transactional
    public void deleteJob(Long jobId, String callerEmail) {
        Job job = findJobOrThrow(jobId);
        User caller = findUserOrThrow(callerEmail);

        if (!job.getRecruiter().getId().equals(caller.getId()) &&
            !caller.getRole().name().equals("ADMIN")) {
            throw new IllegalStateException("You are not authorised to delete this job");
        }

        jobRepository.delete(job);
        log.info("Job deleted: id={} by {}", jobId, callerEmail);
    }

    // ── Private Helpers ──────────────────────────────────────

    private Job findJobOrThrow(Long jobId) {
        return jobRepository.findById(jobId)
            .orElseThrow(() -> new ResourceNotFoundException("Job", "id", jobId));
    }

    private User findUserOrThrow(String email) {
        return userRepository.findByEmail(email)
            .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
    }

    public JobResponse toResponse(Job job) {
        return JobResponse.builder()
            .id(job.getId())
            .title(job.getTitle())
            .description(job.getDescription())
            .company(job.getCompany())
            .location(job.getLocation())
            .salaryRange(job.getSalaryRange())
            .skillsRequired(job.getSkillsRequired())
            .experienceYears(job.getExperienceYears())
            .jobType(job.getJobType())
            .status(job.getStatus())
            .recruiterId(job.getRecruiter().getId())
            .recruiterName(job.getRecruiter().getName())
            .applicationCount(job.getApplications() != null ? job.getApplications().size() : 0)
            .createdAt(job.getCreatedAt())
            .build();
    }
}
