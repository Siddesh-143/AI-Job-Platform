package com.jobportal.service;

import com.jobportal.entity.Resume;
import com.jobportal.entity.User;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.ResumeRepository;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Handles PDF resume upload, storage, and text extraction via the AI service.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ResumeService {

    private final ResumeRepository resumeRepository;
    private final UserRepository   userRepository;
    private final RestTemplate     restTemplate;

    @Value("${file.upload.dir}")
    private String uploadDir;

    @Value("${ai.service.url}")
    private String aiServiceUrl;

    // ── Upload & Extract ──────────────────────────────────────

    /**
     * Store the uploaded PDF and call the AI service to extract text.
     * If a resume already exists for this candidate, it is replaced.
     */
    @Transactional
    public Resume uploadResume(MultipartFile file, String candidateEmail) throws IOException {
        User candidate = userRepository.findByEmail(candidateEmail)
            .orElseThrow(() -> new ResourceNotFoundException("User", "email", candidateEmail));

        // Validate file type
        String contentType = file.getContentType();
        if (contentType == null || !contentType.equalsIgnoreCase("application/pdf")) {
            throw new IllegalArgumentException("Only PDF files are accepted");
        }

        // Build a unique filename to avoid collisions
        String uniqueName = UUID.randomUUID() + "_" + file.getOriginalFilename();
        Path uploadPath   = Paths.get(uploadDir);
        Files.createDirectories(uploadPath);
        Path filePath = uploadPath.resolve(uniqueName);
        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        // Extract text via AI microservice
        String extractedText = extractTextFromPdf(file);

        // Upsert resume record
        Resume resume = resumeRepository.findByCandidateId(candidate.getId())
            .orElse(new Resume());

        resume.setCandidate(candidate);
        resume.setFileName(file.getOriginalFilename());
        resume.setFilePath(filePath.toString());
        resume.setExtractedText(extractedText);

        Resume saved = resumeRepository.save(resume);
        log.info("Resume uploaded for candidate: {} (extracted {} chars)",
                 candidateEmail, extractedText != null ? extractedText.length() : 0);
        return saved;
    }

    /** Fetch a candidate's resume */
    @Transactional(readOnly = true)
    public Resume getResumeByCandidateId(Long candidateId) {
        return resumeRepository.findByCandidateId(candidateId)
            .orElseThrow(() -> new ResourceNotFoundException("Resume", "candidateId", candidateId));
    }

    // ── Call AI Service for PDF Parsing ─────────────

    public String extractTextFromPdf(MultipartFile file) {
        try {
            String endpoint = aiServiceUrl + "/parse-pdf";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);

            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            body.add("file", new org.springframework.core.io.ByteArrayResource(file.getBytes()) {
                @Override public String getFilename() { return file.getOriginalFilename(); }
            });

            HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);
            ResponseEntity<Map> response = restTemplate.postForEntity(endpoint, request, Map.class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return (String) response.getBody().get("text");
            }
        } catch (Exception ex) {
            log.error("PDF parse failed via AI service: {}", ex.getMessage());
        }
        return "";
    }
}
