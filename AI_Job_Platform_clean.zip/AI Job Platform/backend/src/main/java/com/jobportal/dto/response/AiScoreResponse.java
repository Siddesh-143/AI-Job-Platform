package com.jobportal.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Response payload for the AI analysis result of a specific application.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AiScoreResponse {
    private Long              id;
    private Long              applicationId;
    private Double            matchScore;
    private List<String>      matchedSkills;
    private List<String>      missingSkills;
    private List<String>      suggestions;
    private LocalDateTime     analyzedAt;
}
