package com.jobportal.config;

import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.enums.Role;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final JobRepository jobRepository;
    private final PasswordEncoder passwordEncoder;

    public DataSeeder(UserRepository userRepository, JobRepository jobRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.jobRepository = jobRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        // Only insert if no jobs exist
        if (jobRepository.count() == 0) {
            
            // Create a demo recruiter if they don't exist
            User recruiter = userRepository.findByEmail("alice@techcorp.com").orElseGet(() -> {
                User u = User.builder()
                        .name("Alice Recruiter")
                        .email("alice@techcorp.com")
                        .password(passwordEncoder.encode("password123"))
                        .role(Role.RECRUITER)
                        .isActive(true)
                        .build();
                return userRepository.save(u);
            });

            // Create some dummy jobs
            Job job1 = Job.builder()
                    .title("Senior Java Backend Developer")
                    .company("TechCorp Solutions")
                    .description("We are looking for an experienced Java developer to design and build scalable REST APIs. You will work with Spring Boot, Microservices architecture, and deploy on AWS.")
                    .location("Bangalore, India")
                    .salaryRange("15–25 LPA")
                    .skillsRequired("Java,Spring Boot,Microservices,REST API,MySQL,AWS,Docker")
                    .experienceYears("3–5 years")
                    .jobType("FULL_TIME")
                    .status("OPEN")
                    .recruiter(recruiter)
                    .build();

            Job job2 = Job.builder()
                    .title("Full Stack Developer (React + Node)")
                    .company("TechCorp Solutions")
                    .description("Join our product team to build modern web applications. You will develop both front-end features in React and back-end services in Node.js.")
                    .location("Remote")
                    .salaryRange("10–18 LPA")
                    .skillsRequired("React,Node.js,JavaScript,MongoDB,REST API,AWS")
                    .experienceYears("2–4 years")
                    .jobType("FULL_TIME")
                    .status("OPEN")
                    .recruiter(recruiter)
                    .build();

            Job job3 = Job.builder()
                    .title("Python Data Engineer")
                    .company("FinTech Innovations")
                    .description("Build and maintain data pipelines using Python and Apache Spark. Work on big data infrastructure, ETL processes, and data warehousing.")
                    .location("Hyderabad, India")
                    .salaryRange("12–20 LPA")
                    .skillsRequired("Python,Apache Spark,ETL,SQL,AWS,Hadoop")
                    .experienceYears("2–5 years")
                    .jobType("FULL_TIME")
                    .status("OPEN")
                    .recruiter(recruiter)
                    .build();
                    
            Job job4 = Job.builder()
                    .title("Frontend Developer Intern")
                    .company("TechCorp Solutions")
                    .description("A great opportunity for freshers to work on exciting UI projects. You will build React components and learn industry best practices.")
                    .location("Pune, India")
                    .salaryRange("25,000–35,000/month")
                    .skillsRequired("React,JavaScript,HTML,CSS,Git")
                    .experienceYears("0–1 years")
                    .jobType("INTERNSHIP")
                    .status("OPEN")
                    .recruiter(recruiter)
                    .build();

            jobRepository.saveAll(List.of(job1, job2, job3, job4));
            System.out.println("✅ Dummy jobs successfully inserted into the database!");
        }
    }
}
