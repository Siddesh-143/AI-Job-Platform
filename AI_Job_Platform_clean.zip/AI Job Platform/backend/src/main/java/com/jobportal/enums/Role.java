package com.jobportal.enums;

/**
 * User roles supported by the portal.
 * ADMIN     - Full system access
 * RECRUITER - Can post jobs and manage applications
 * CANDIDATE - Can apply for jobs and upload resumes
 */
public enum Role {
    ADMIN,
    RECRUITER,
    CANDIDATE
}
