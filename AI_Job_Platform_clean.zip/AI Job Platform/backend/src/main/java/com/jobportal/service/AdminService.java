package com.jobportal.service;

import com.jobportal.dto.response.AnalyticsResponse;
import com.jobportal.dto.response.UserResponse;
import com.jobportal.entity.User;
import com.jobportal.enums.ApplicationStatus;
import com.jobportal.enums.Role;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.ApplicationRepository;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Admin-only service for user management and system analytics.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AdminService {

    private final UserRepository        userRepository;
    private final JobRepository         jobRepository;
    private final ApplicationRepository applicationRepository;

    // ── User Management ──────────────────────────────────────

    /** List all users in the system */
    @Transactional(readOnly = true)
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll()
            .stream()
            .map(this::toUserResponse)
            .collect(Collectors.toList());
    }

    /** Toggle a user's active/blocked status */
    @Transactional
    public UserResponse toggleUserStatus(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        user.setActive(!user.isActive());
        User saved = userRepository.save(user);
        log.info("Admin toggled user id={} → isActive={}", userId, saved.isActive());
        return toUserResponse(saved);
    }

    /** Permanently delete a user account */
    @Transactional
    public void deleteUser(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
        userRepository.delete(user);
        log.info("Admin deleted user id={}", userId);
    }

    // ── Analytics ────────────────────────────────────────────

    /** Compile system-wide statistics for the admin dashboard */
    @Transactional(readOnly = true)
    public AnalyticsResponse getAnalytics() {
        return AnalyticsResponse.builder()
            .totalUsers(userRepository.count())
            .totalRecruiters(userRepository.countByRole(Role.RECRUITER))
            .totalCandidates(userRepository.countByRole(Role.CANDIDATE))
            .totalJobs(jobRepository.count())
            .openJobs(jobRepository.countByStatus("OPEN"))
            .closedJobs(jobRepository.countByStatus("CLOSED"))
            .totalApplications(applicationRepository.count())
            .pendingApplications(applicationRepository.countByStatus(ApplicationStatus.PENDING))
            .shortlistedApplications(applicationRepository.countByStatus(ApplicationStatus.SHORTLISTED))
            .rejectedApplications(applicationRepository.countByStatus(ApplicationStatus.REJECTED))
            .build();
    }

    // ── Private Helper ───────────────────────────────────────

    private UserResponse toUserResponse(User user) {
        return UserResponse.builder()
            .id(user.getId())
            .name(user.getName())
            .email(user.getEmail())
            .role(user.getRole().name())
            .isActive(user.isActive())
            .createdAt(user.getCreatedAt())
            .build();
    }
}
