package com.jobportal.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * General application beans not tied to security.
 */
@Configuration
public class AppConfig {

    /**
     * RestTemplate used by AiAnalysisService and ResumeService
     * to call the Python FastAPI microservice.
     */
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    /**
     * Jackson ObjectMapper with Java 8 date/time support enabled.
     * Used for serialising/deserialising AI score JSON arrays.
     */
    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        return mapper;
    }
}
