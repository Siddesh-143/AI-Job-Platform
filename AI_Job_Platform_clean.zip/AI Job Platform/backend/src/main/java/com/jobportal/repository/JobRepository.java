package com.jobportal.repository;

import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data JPA repository for Job entity.
 */
@Repository
public interface JobRepository extends JpaRepository<Job, Long> {

    /** All open jobs (for candidates browsing) */
    List<Job> findByStatus(String status);

    /** Jobs posted by a specific recruiter */
    List<Job> findByRecruiter(User recruiter);

    /** Jobs posted by recruiter with given id */
    List<Job> findByRecruiterId(Long recruiterId);

    /** Search jobs by title or company (case-insensitive) */
    @Query("SELECT j FROM Job j WHERE " +
           "LOWER(j.title)   LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(j.company) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(j.location) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Job> searchJobs(@Param("keyword") String keyword);

    /** Count total jobs (Admin analytics) */
    long count();

    /** Count open jobs */
    long countByStatus(String status);
}
