-- ============================================================
--  Smart Job Portal — Seed / Sample Data
--  Passwords are BCrypt of "password123"
-- ============================================================

USE job_portal_db;

-- ------------------------------------------------------------
-- Users: 1 Admin, 2 Recruiters, 3 Candidates
-- Password for ALL accounts: password123
-- BCrypt hash of "password123"
-- ------------------------------------------------------------
INSERT INTO users (name, email, password, role) VALUES
('System Admin',      'admin@jobportal.com',    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh7e', 'ADMIN'),
('Alice Recruiter',   'alice@techcorp.com',     '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh7e', 'RECRUITER'),
('Bob Recruiter',     'bob@fintech.com',        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh7e', 'RECRUITER'),
('Charlie Candidate', 'charlie@gmail.com',      '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh7e', 'CANDIDATE'),
('Diana Candidate',   'diana@gmail.com',        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh7e', 'CANDIDATE'),
('Eve Candidate',     'eve@gmail.com',          '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh7e', 'CANDIDATE');

-- ------------------------------------------------------------
-- Jobs
-- ------------------------------------------------------------
INSERT INTO jobs (title, description, company, location, salary_range, skills_required, experience_years, job_type, recruiter_id) VALUES
(
    'Senior Java Backend Developer',
    'We are looking for an experienced Java developer to design and build scalable REST APIs. You will work with Spring Boot, Microservices architecture, and deploy on AWS. Must have strong knowledge of databases and system design.',
    'TechCorp Solutions',
    'Bangalore, India',
    '15–25 LPA',
    'Java,Spring Boot,Microservices,REST API,MySQL,AWS,Docker,Kafka,Redis',
    '3–5 years',
    'FULL_TIME',
    2
),
(
    'Full Stack Developer (React + Node)',
    'Join our product team to build modern web applications. You will develop both front-end features in React and back-end services in Node.js. Experience with MongoDB and cloud deployment required.',
    'TechCorp Solutions',
    'Remote',
    '10–18 LPA',
    'React,Node.js,JavaScript,MongoDB,REST API,HTML,CSS,TypeScript,AWS',
    '2–4 years',
    'FULL_TIME',
    2
),
(
    'Python Data Engineer',
    'Build and maintain data pipelines using Python and Apache Spark. Work on big data infrastructure, ETL processes, and data warehousing. Collaborate with data scientists to productionize ML models.',
    'FinTech Innovations',
    'Hyderabad, India',
    '12–20 LPA',
    'Python,Apache Spark,ETL,SQL,AWS,Hadoop,Airflow,Kafka,Machine Learning',
    '2–5 years',
    'FULL_TIME',
    3
),
(
    'DevOps Engineer',
    'Manage CI/CD pipelines, Kubernetes clusters, and cloud infrastructure. Automate deployments using Terraform and Ansible. Ensure 99.9% uptime of production services.',
    'FinTech Innovations',
    'Mumbai, India',
    '14–22 LPA',
    'Kubernetes,Docker,AWS,Terraform,Ansible,CI/CD,Jenkins,Linux,Python',
    '3–6 years',
    'FULL_TIME',
    3
),
(
    'Frontend Developer Intern',
    'A great opportunity for freshers to work on exciting UI projects. You will build React components and learn industry best practices. Mentorship provided.',
    'TechCorp Solutions',
    'Pune, India',
    '25,000–35,000/month',
    'React,JavaScript,HTML,CSS,Git',
    '0–1 years',
    'INTERNSHIP',
    2
);

-- ------------------------------------------------------------
-- Applications (candidates applying to jobs)
-- ------------------------------------------------------------
INSERT INTO applications (candidate_id, job_id, status, cover_letter) VALUES
(4, 1, 'SHORTLISTED', 'I have 4 years of Java experience and am excited about this role.'),
(4, 2, 'PENDING',     'I am a versatile developer with React and Node.js experience.'),
(5, 1, 'REJECTED',    'Fresh graduate eager to learn Java backend development.'),
(5, 3, 'PENDING',     'I have worked on Python data pipelines during my internship.'),
(6, 5, 'PENDING',     'As a final-year student I have built multiple React projects.');

-- ------------------------------------------------------------
-- AI Scores (sample pre-computed scores)
-- ------------------------------------------------------------
INSERT INTO ai_scores (application_id, match_score, matched_skills, missing_skills, suggestions, analyzed_at) VALUES
(
    1,
    82.50,
    '["Java","Spring Boot","REST API","MySQL","Docker"]',
    '["AWS","Kafka","Redis","Microservices"]',
    '["Get AWS Certified Solutions Architect certification","Learn Apache Kafka for event streaming","Add Redis caching experience to your resume"]',
    NOW()
),
(
    3,
    34.00,
    '["Java","REST API"]',
    '["Spring Boot","Microservices","MySQL","AWS","Docker","Kafka","Redis"]',
    '["Take a Spring Boot course on Udemy","Build a microservice project on GitHub","Learn Docker and containerization basics"]',
    NOW()
);
