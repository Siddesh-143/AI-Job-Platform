-- ============================================================
--  Smart Job Portal with AI Resume Analyzer
--  Database Schema — MySQL 8.x
-- ============================================================

CREATE DATABASE IF NOT EXISTS job_portal_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE job_portal_db;

-- ------------------------------------------------------------
-- Table: users
-- Stores all system users (Admin, Recruiter, Candidate)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id          BIGINT          NOT NULL AUTO_INCREMENT,
    name        VARCHAR(100)    NOT NULL,
    email       VARCHAR(150)    NOT NULL UNIQUE,
    password    VARCHAR(255)    NOT NULL,           -- BCrypt hash
    role        ENUM('ADMIN','RECRUITER','CANDIDATE') NOT NULL DEFAULT 'CANDIDATE',
    is_active   BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_users_email (email),
    INDEX idx_users_role  (role)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: jobs
-- Posted by recruiters; stores JD and skill requirements
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS jobs (
    id              BIGINT          NOT NULL AUTO_INCREMENT,
    title           VARCHAR(200)    NOT NULL,
    description     TEXT            NOT NULL,
    company         VARCHAR(150)    NOT NULL,
    location        VARCHAR(100),
    salary_range    VARCHAR(50),
    skills_required TEXT,           -- comma-separated skill keywords
    experience_years VARCHAR(30),
    job_type        ENUM('FULL_TIME','PART_TIME','CONTRACT','INTERNSHIP') DEFAULT 'FULL_TIME',
    status          ENUM('OPEN','CLOSED') NOT NULL DEFAULT 'OPEN',
    recruiter_id    BIGINT          NOT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_jobs_recruiter (recruiter_id),
    INDEX idx_jobs_status    (status),
    CONSTRAINT fk_jobs_recruiter FOREIGN KEY (recruiter_id)
        REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: resumes
-- One resume per candidate; stores file path and extracted text
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS resumes (
    id              BIGINT          NOT NULL AUTO_INCREMENT,
    candidate_id    BIGINT          NOT NULL UNIQUE,
    file_name       VARCHAR(255)    NOT NULL,
    file_path       VARCHAR(500)    NOT NULL,
    extracted_text  LONGTEXT,       -- full text extracted from PDF
    uploaded_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_resumes_candidate FOREIGN KEY (candidate_id)
        REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: applications
-- Tracks which candidate applied to which job
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS applications (
    id              BIGINT          NOT NULL AUTO_INCREMENT,
    candidate_id    BIGINT          NOT NULL,
    job_id          BIGINT          NOT NULL,
    status          ENUM('PENDING','SHORTLISTED','REJECTED') NOT NULL DEFAULT 'PENDING',
    cover_letter    TEXT,
    applied_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE INDEX uq_application (candidate_id, job_id),   -- one application per job
    INDEX idx_applications_candidate (candidate_id),
    INDEX idx_applications_job       (job_id),
    CONSTRAINT fk_applications_candidate FOREIGN KEY (candidate_id)
        REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_applications_job      FOREIGN KEY (job_id)
        REFERENCES jobs(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: ai_scores
-- Stores AI analysis results for each application
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ai_scores (
    id              BIGINT          NOT NULL AUTO_INCREMENT,
    application_id  BIGINT          NOT NULL UNIQUE,
    match_score     DECIMAL(5,2),                   -- 0.00 – 100.00
    matched_skills  TEXT,                           -- JSON array string
    missing_skills  TEXT,                           -- JSON array string
    suggestions     TEXT,                           -- JSON array string
    analyzed_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_ai_scores_application (application_id),
    CONSTRAINT fk_ai_scores_application FOREIGN KEY (application_id)
        REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB;
