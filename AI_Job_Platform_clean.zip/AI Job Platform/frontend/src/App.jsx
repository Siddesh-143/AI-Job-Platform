import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import Navbar from './components/Navbar'
import LoginPage from './pages/LoginPage'
import SignupPage from './pages/SignupPage'
import Dashboard from './pages/Dashboard'
import JobListingPage from './pages/JobListingPage'
import JobDetailPage from './pages/JobDetailPage'
import ResumeUploadPage from './pages/ResumeUploadPage'
import ApplicationsPage from './pages/ApplicationsPage'
import PostJobPage from './pages/PostJobPage'
import ApplicantsPage from './pages/ApplicantsPage'
import AdminPanel from './pages/AdminPanel'

// ── Route Guards ─────────────────────────────────────────────

/** Redirect unauthenticated users to /login */
function PrivateRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return <div className="spinner" />
  return user ? children : <Navigate to="/login" replace />
}

/** Redirect authenticated users away from auth pages */
function PublicRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return <div className="spinner" />
  return !user ? children : <Navigate to="/dashboard" replace />
}

/** Only allow specific roles */
function RoleRoute({ children, roles }) {
  const { user, loading } = useAuth()
  if (loading) return <div className="spinner" />
  if (!user) return <Navigate to="/login" replace />
  if (!roles.includes(user.role)) return <Navigate to="/dashboard" replace />
  return children
}

// ── App Shell ─────────────────────────────────────────────────
function AppShell() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        {/* Public */}
        <Route path="/" element={<Navigate to="/jobs" replace />} />
        <Route path="/login"  element={<PublicRoute><LoginPage  /></PublicRoute>} />
        <Route path="/signup" element={<PublicRoute><SignupPage /></PublicRoute>} />
        <Route path="/jobs"         element={<JobListingPage />} />
        <Route path="/jobs/:id"     element={<JobDetailPage  />} />

        {/* Authenticated — any role */}
        <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />

        {/* Candidate only */}
        <Route path="/resume/upload"  element={<RoleRoute roles={['CANDIDATE']}><ResumeUploadPage /></RoleRoute>} />
        <Route path="/my-applications" element={<RoleRoute roles={['CANDIDATE']}><ApplicationsPage /></RoleRoute>} />

        {/* Recruiter only */}
        <Route path="/post-job"            element={<RoleRoute roles={['RECRUITER']}><PostJobPage    /></RoleRoute>} />
        <Route path="/edit-job/:id"        element={<RoleRoute roles={['RECRUITER','ADMIN']}><PostJobPage /></RoleRoute>} />
        <Route path="/applicants/:jobId"   element={<RoleRoute roles={['RECRUITER','ADMIN']}><ApplicantsPage /></RoleRoute>} />

        {/* Admin only */}
        <Route path="/admin" element={<RoleRoute roles={['ADMIN']}><AdminPanel /></RoleRoute>} />

        {/* 404 */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <AppShell />
    </AuthProvider>
  )
}
