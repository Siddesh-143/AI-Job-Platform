import { useEffect, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { jobsAPI } from '../services/api'
import { useAuth } from '../context/AuthContext'

export default function PostJobPage() {
  const { id }     = useParams()    // defined if editing
  const { user }   = useAuth()
  const navigate   = useNavigate()
  const isEdit     = Boolean(id)

  const [form, setForm] = useState({
    title:'', description:'', company:'', location:'',
    salaryRange:'', skillsRequired:'', experienceYears:'',
    jobType:'FULL_TIME', status:'OPEN',
  })
  const [loading, setLoading] = useState(false)
  const [fetching, setFetching] = useState(isEdit)
  const [error, setError]     = useState('')

  useEffect(() => {
    if (isEdit) {
      jobsAPI.getById(id)
        .then(r => setForm({ ...r.data }))
        .catch(() => navigate('/dashboard'))
        .finally(() => setFetching(false))
    }
  }, [id])

  const handleChange = (e) =>
    setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.skillsRequired.trim()) { setError('Skills required field is mandatory'); return }
    setLoading(true)
    setError('')
    try {
      if (isEdit) {
        await jobsAPI.update(id, form)
      } else {
        await jobsAPI.create(form)
      }
      navigate('/dashboard')
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to save job')
    } finally { setLoading(false) }
  }

  if (fetching) return (
    <div className="page-wrapper">
      <div className="loading-overlay"><div className="spinner" /><p>Loading job…</p></div>
    </div>
  )

  return (
    <div className="page-wrapper animate-in">
      <div style={{ maxWidth:720, margin:'0 auto' }}>
        <div style={{ marginBottom:32 }}>
          <Link to="/dashboard" style={{ fontSize:'0.85rem', color:'var(--text-muted)' }}>← Back to Dashboard</Link>
          <h1 style={{ marginTop:12 }}>{isEdit ? 'Edit Job' : 'Post a New Job'}</h1>
          <p style={{ marginTop:6 }}>
            Fill in the job details. The <strong style={{color:'var(--accent-2)'}}>Skills Required</strong> field
            is used by our AI to score candidates automatically.
          </p>
        </div>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit} className="card">
          {/* Row 1 */}
          <div className="grid-2">
            <div className="form-group">
              <label htmlFor="title">Job Title *</label>
              <input id="title" name="title" placeholder="e.g. Senior Java Developer"
                value={form.title} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label htmlFor="company">Company Name *</label>
              <input id="company" name="company" placeholder="e.g. TechCorp Solutions"
                value={form.company} onChange={handleChange} required />
            </div>
          </div>

          {/* Row 2 */}
          <div className="grid-2">
            <div className="form-group">
              <label htmlFor="location">Location</label>
              <input id="location" name="location" placeholder="e.g. Bangalore / Remote"
                value={form.location} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label htmlFor="salaryRange">Salary Range</label>
              <input id="salaryRange" name="salaryRange" placeholder="e.g. 10–18 LPA"
                value={form.salaryRange} onChange={handleChange} />
            </div>
          </div>

          {/* Row 3 */}
          <div className="grid-2">
            <div className="form-group">
              <label htmlFor="jobType">Job Type</label>
              <select id="jobType" name="jobType" value={form.jobType} onChange={handleChange}>
                <option value="FULL_TIME">Full-time</option>
                <option value="PART_TIME">Part-time</option>
                <option value="CONTRACT">Contract</option>
                <option value="INTERNSHIP">Internship</option>
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="experienceYears">Experience Required</label>
              <input id="experienceYears" name="experienceYears" placeholder="e.g. 3–5 years"
                value={form.experienceYears} onChange={handleChange} />
            </div>
          </div>

          {/* Skills — highlighted, used by AI */}
          <div className="form-group">
            <label htmlFor="skillsRequired">
              Skills Required * &nbsp;
              <span style={{color:'var(--accent-2)', fontWeight:400, fontSize:'0.78rem'}}>
                🤖 Used for AI matching — comma-separated
              </span>
            </label>
            <input
              id="skillsRequired" name="skillsRequired"
              placeholder="Java, Spring Boot, MySQL, Docker, AWS"
              value={form.skillsRequired}
              onChange={handleChange}
              style={{ borderColor: 'rgba(6,214,160,0.4)' }}
              required
            />
          </div>

          {/* Description */}
          <div className="form-group">
            <label htmlFor="description">Job Description *</label>
            <textarea
              id="description" name="description"
              placeholder="Describe the role, responsibilities, and team culture…"
              rows={8}
              value={form.description}
              onChange={handleChange}
              required
            />
          </div>

          {/* Status (edit only) */}
          {isEdit && (
            <div className="form-group">
              <label htmlFor="status">Status</label>
              <select id="status" name="status" value={form.status} onChange={handleChange}>
                <option value="OPEN">Open</option>
                <option value="CLOSED">Closed</option>
              </select>
            </div>
          )}

          <div style={{ display:'flex', gap:12 }}>
            <button type="submit" className="btn btn-primary btn-lg" disabled={loading}>
              {loading ? 'Saving…' : isEdit ? 'Update Job' : 'Post Job →'}
            </button>
            <Link to="/dashboard" className="btn btn-secondary btn-lg">Cancel</Link>
          </div>
        </form>
      </div>
    </div>
  )
}
