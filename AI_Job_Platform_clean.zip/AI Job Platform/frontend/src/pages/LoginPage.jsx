import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { authAPI } from '../services/api'
import './AuthPages.css'

export default function LoginPage() {
  const [form, setForm]       = useState({ email: '', password: '' })
  const [error, setError]     = useState('')
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate  = useNavigate()

  const handleChange = (e) =>
    setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const { data } = await authAPI.login(form)
      login(data.token, { id: data.id, name: data.name, email: data.email, role: data.role })
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid email or password')
    } finally {
      setLoading(false)
    }
  }

  const fillDemo = (role) => {
    const demos = {
      admin:     { email: 'admin@jobportal.com',  password: 'password123' },
      recruiter: { email: 'alice@techcorp.com',   password: 'password123' },
      candidate: { email: 'charlie@gmail.com',    password: 'password123' },
    }
    setForm(demos[role])
  }

  return (
    <div className="auth-page">
      {/* Left panel — hero */}
      <div className="auth-hero">
        <div className="auth-hero-content">
          <div className="hero-badge">🤖 AI-Powered</div>
          <h1 className="hero-title">Find your<br/><span className="gradient-text">perfect job</span><br/>with AI</h1>
          <p className="hero-sub">
            Our AI analyzes your resume against job descriptions and gives
            you a real match score — so you apply smarter, not harder.
          </p>
          <div className="hero-stats">
            <div className="hero-stat"><span className="stat-num">5+</span><span>Jobs Listed</span></div>
            <div className="hero-stat"><span className="stat-num">AI</span><span>Match Score</span></div>
            <div className="hero-stat"><span className="stat-num">3</span><span>Roles</span></div>
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="auth-form-panel">
        <div className="auth-form-card animate-in">
          <div className="auth-form-header">
            <Link to="/" className="navbar-logo" style={{marginBottom:'8px', display:'inline-flex'}}>
              <span className="logo-icon">⚡</span>
              <span className="logo-text">Smart<span className="logo-accent">Hire</span></span>
            </Link>
            <h2>Welcome back</h2>
            <p>Sign in to your account to continue</p>
          </div>

          {error && <div className="alert alert-error">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <input
                id="email" name="email" type="email"
                placeholder="you@example.com"
                value={form.email} onChange={handleChange} required
              />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input
                id="password" name="password" type="password"
                placeholder="••••••••"
                value={form.password} onChange={handleChange} required
              />
            </div>
            <button type="submit" className="btn btn-primary btn-lg w-full" disabled={loading}>
              {loading ? 'Signing in…' : 'Sign In →'}
            </button>
          </form>

          {/* Demo quick-fill buttons */}
          <div className="demo-section">
            <p className="demo-label">Quick demo login:</p>
            <div className="demo-buttons">
              <button className="btn btn-secondary btn-sm" onClick={() => fillDemo('admin')}>
                Admin
              </button>
              <button className="btn btn-secondary btn-sm" onClick={() => fillDemo('recruiter')}>
                Recruiter
              </button>
              <button className="btn btn-secondary btn-sm" onClick={() => fillDemo('candidate')}>
                Candidate
              </button>
            </div>
          </div>

          <p className="auth-switch">
            Don't have an account? <Link to="/signup">Sign up free</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
