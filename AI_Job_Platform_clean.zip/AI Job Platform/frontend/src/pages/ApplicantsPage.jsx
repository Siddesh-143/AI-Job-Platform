import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { applicationsAPI, jobsAPI } from '../services/api'

const STATUS_OPTIONS = ['PENDING', 'SHORTLISTED', 'REJECTED']

export default function ApplicantsPage() {
  const { jobId } = useParams()
  const [job, setJob]       = useState(null)
  const [apps, setApps]     = useState([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState(null)
  const [updatingId, setUpdatingId] = useState(null)

  useEffect(() => {
    Promise.all([
      jobsAPI.getById(jobId),
      applicationsAPI.getForJob(jobId),
    ])
    .then(([jobRes, appsRes]) => {
      setJob(jobRes.data)
      setApps(appsRes.data)
    })
    .catch(console.error)
    .finally(() => setLoading(false))
  }, [jobId])

  const updateStatus = async (appId, status) => {
    setUpdatingId(appId)
    try {
      const { data } = await applicationsAPI.updateStatus(appId, status)
      setApps(prev => prev.map(a => a.id === appId ? { ...a, status: data.status } : a))
    } catch (e) { alert('Failed to update status') }
    finally { setUpdatingId(null) }
  }

  const statusColor = { PENDING:'warning', SHORTLISTED:'success', REJECTED:'danger' }
  const shortlisted = apps.filter(a => a.status === 'SHORTLISTED').length

  if (loading) return (
    <div className="page-wrapper">
      <div className="loading-overlay"><div className="spinner" /><p>Loading applicants…</p></div>
    </div>
  )

  return (
    <div className="page-wrapper animate-in">
      {/* Header */}
      <div style={{ marginBottom:32 }}>
        <Link to="/dashboard" style={{ fontSize:'0.85rem', color:'var(--text-muted)' }}>← Back to Dashboard</Link>
        <h1 style={{ marginTop:12 }}>{job?.title}</h1>
        <p style={{ marginTop:6 }}>{job?.company} • {job?.location}</p>
        <div style={{ display:'flex', gap:12, marginTop:12, flexWrap:'wrap' }}>
          <span className="badge badge-info">{apps.length} Total Applicants</span>
          <span className="badge badge-success">{shortlisted} Shortlisted</span>
          <span className="badge badge-warning">{apps.filter(a=>a.status==='PENDING').length} Pending</span>
          <span className="badge badge-danger">{apps.filter(a=>a.status==='REJECTED').length} Rejected</span>
        </div>
      </div>

      {apps.length === 0 ? (
        <div className="empty-state card">
          <div className="empty-icon">👥</div>
          <h3>No applicants yet</h3>
          <p>Candidates will appear here after they apply</p>
        </div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          {apps
            .sort((a,b) => (b.aiScore?.matchScore || 0) - (a.aiScore?.matchScore || 0))
            .map((app, i) => (
            <div key={app.id} className="card animate-in" style={{animationDelay:`${i*0.04}s`}}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12 }}>
                {/* Candidate info */}
                <div style={{ display:'flex', gap:14, flex:1 }}>
                  <div style={{
                    width:44, height:44, borderRadius:'50%',
                    background:'var(--gradient-primary)', display:'flex',
                    alignItems:'center', justifyContent:'center',
                    fontFamily:'var(--font-display)', fontWeight:700, fontSize:'1.1rem',
                    flexShrink:0, color:'#fff',
                  }}>
                    {app.candidateName?.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h3 style={{ marginBottom:2 }}>{app.candidateName}</h3>
                    <p style={{ fontSize:'0.82rem', color:'var(--text-muted)', marginBottom:8 }}>
                      {app.candidateEmail}
                    </p>
                    <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                      <span className={`badge badge-${statusColor[app.status]}`}>{app.status}</span>
                      <span style={{fontSize:'0.75rem', color:'var(--text-muted)'}}>
                        Applied {new Date(app.appliedAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                {/* AI score + actions */}
                <div style={{ display:'flex', gap:16, alignItems:'center' }}>
                  {app.aiScore ? (
                    <div style={{ textAlign:'center' }}>
                      <div style={{
                        width:56, height:56, borderRadius:'50%',
                        background:`conic-gradient(${app.aiScore.matchScore>=70?'var(--success)':app.aiScore.matchScore>=40?'var(--warning)':'var(--danger)'} ${app.aiScore.matchScore*3.6}deg, rgba(255,255,255,0.06) 0deg)`,
                        display:'flex', alignItems:'center', justifyContent:'center',
                      }}>
                        <div style={{
                          width:42, height:42, borderRadius:'50%',
                          background:'var(--bg-secondary)',
                          display:'flex', alignItems:'center', justifyContent:'center',
                          fontWeight:800, fontSize:'0.85rem',
                          color: app.aiScore.matchScore>=70?'var(--success)':app.aiScore.matchScore>=40?'var(--warning)':'var(--danger)',
                        }}>
                          {Math.round(app.aiScore.matchScore)}%
                        </div>
                      </div>
                      <p style={{fontSize:'0.65rem', color:'var(--text-muted)', marginTop:4}}>AI Match</p>
                    </div>
                  ) : (
                    <span style={{fontSize:'1.4rem'}}>⏳</span>
                  )}

                  {/* Status dropdown */}
                  <select
                    value={app.status}
                    onChange={e => updateStatus(app.id, e.target.value)}
                    disabled={updatingId === app.id}
                    style={{ padding:'8px 12px', borderRadius:'var(--radius-md)', minWidth:130 }}
                  >
                    {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              {/* Expand AI details */}
              {app.aiScore && (
                <div>
                  <button
                    className="btn btn-secondary btn-sm"
                    style={{ marginTop:12 }}
                    onClick={() => setExpanded(expanded === app.id ? null : app.id)}
                  >
                    {expanded === app.id ? 'Hide AI Analysis ▲' : 'Show AI Analysis ▼'}
                  </button>
                  {expanded === app.id && (
                    <div style={{ marginTop:16, borderTop:'1px solid var(--border)', paddingTop:16 }} className="animate-fade">
                      <div className="grid-2" style={{ gap:16, marginBottom:16 }}>
                        <div>
                          <p style={{fontSize:'0.75rem', fontWeight:700, color:'var(--success)', marginBottom:6}}>
                            ✅ MATCHED SKILLS
                          </p>
                          {app.aiScore.matchedSkills?.map(s => (
                            <span key={s} className="skill-chip matched">{s}</span>
                          ))}
                        </div>
                        <div>
                          <p style={{fontSize:'0.75rem', fontWeight:700, color:'var(--danger)', marginBottom:6}}>
                            ❌ MISSING SKILLS
                          </p>
                          {app.aiScore.missingSkills?.map(s => (
                            <span key={s} className="skill-chip missing">{s}</span>
                          ))}
                        </div>
                      </div>
                      {app.coverLetter && (
                        <div style={{ background:'rgba(255,255,255,0.03)', padding:'12px 16px',
                          borderRadius:'var(--radius-md)', fontSize:'0.88rem' }}>
                          <strong style={{fontSize:'0.75rem', color:'var(--text-muted)'}}>COVER LETTER</strong>
                          <p style={{marginTop:6}}>{app.coverLetter}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
