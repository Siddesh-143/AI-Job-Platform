import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { jobsAPI, applicationsAPI, adminAPI } from '../services/api'

export default function Dashboard() {
  const { user } = useAuth()
  const [stats, setStats]   = useState(null)
  const [items, setItems]   = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDashboard()
  }, [user])

  const loadDashboard = async () => {
    setLoading(true)
    try {
      if (user.role === 'ADMIN') {
        const { data } = await adminAPI.getAnalytics()
        setStats(data)
      } else if (user.role === 'RECRUITER') {
        const { data } = await jobsAPI.getMyJobs(user.id)
        setItems(data)
      } else {
        const { data } = await applicationsAPI.getMyApps()
        setItems(data)
      }
    } catch (e) { console.error(e) }
    finally { setLoading(false) }
  }

  if (loading) return (
    <div className="page-wrapper">
      <div className="loading-overlay"><div className="spinner" /><p>Loading dashboard…</p></div>
    </div>
  )

  return (
    <div className="page-wrapper animate-in">
      {/* Header */}
      <div style={{ marginBottom: '32px' }}>
        <p style={{ color: 'var(--accent-2)', fontWeight: 600, marginBottom: 4 }}>
          Welcome back 👋
        </p>
        <h1>{user.name}</h1>
        <p style={{ marginTop: 8 }}>
          <span className={`badge badge-${user.role === 'ADMIN' ? 'danger' : user.role === 'RECRUITER' ? 'info' : 'success'}`}>
            {user.role}
          </span>
        </p>
      </div>

      {/* ── ADMIN Dashboard ── */}
      {user.role === 'ADMIN' && stats && (
        <>
          <h2 style={{ marginBottom: 20 }}>System Analytics</h2>
          <div className="grid-4" style={{ marginBottom: 32 }}>
            <StatCard label="Total Users"        value={stats.totalUsers}      icon="👥" color="var(--accent-1)" />
            <StatCard label="Recruiters"          value={stats.totalRecruiters} icon="🏢" color="var(--info)" />
            <StatCard label="Candidates"          value={stats.totalCandidates} icon="👤" color="var(--accent-2)" />
            <StatCard label="Total Jobs"          value={stats.totalJobs}       icon="💼" color="var(--warning)" />
          </div>
          <div className="grid-3" style={{ marginBottom: 32 }}>
            <StatCard label="Open Jobs"           value={stats.openJobs}              icon="🟢" color="var(--success)" />
            <StatCard label="Total Applications"  value={stats.totalApplications}     icon="📋" color="var(--accent-1)" />
            <StatCard label="Shortlisted"         value={stats.shortlistedApplications} icon="⭐" color="var(--warning)" />
          </div>
          <div style={{ display:'flex', gap:12, flexWrap:'wrap' }}>
            <Link to="/admin" className="btn btn-primary">Go to Admin Panel →</Link>
            <Link to="/jobs/all" className="btn btn-secondary">Manage Jobs</Link>
          </div>
        </>
      )}

      {/* ── RECRUITER Dashboard ── */}
      {user.role === 'RECRUITER' && (
        <>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:24 }}>
            <h2>Your Job Postings</h2>
            <Link to="/post-job" className="btn btn-primary">+ Post New Job</Link>
          </div>
          {items.length === 0 ? (
            <div className="empty-state card">
              <div className="empty-icon">💼</div>
              <h3>No jobs posted yet</h3>
              <p>Start by posting your first job opening</p>
              <Link to="/post-job" className="btn btn-primary" style={{marginTop:16}}>Post a Job</Link>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
              {items.map(job => (
                <div key={job.id} className="card" style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                  <div>
                    <h3 style={{ marginBottom:6 }}>{job.title}</h3>
                    <p style={{ fontSize:'0.85rem', marginBottom:8 }}>{job.company} • {job.location}</p>
                    <div style={{ display:'flex', gap:8 }}>
                      <span className={`badge badge-${job.status === 'OPEN' ? 'success' : 'danger'}`}>{job.status}</span>
                      <span className="badge badge-info">{job.applicationCount} applicants</span>
                    </div>
                  </div>
                  <div style={{ display:'flex', gap:10 }}>
                    <Link to={`/applicants/${job.id}`} className="btn btn-secondary btn-sm">View Applicants</Link>
                    <Link to={`/edit-job/${job.id}`} className="btn btn-secondary btn-sm">Edit</Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* ── CANDIDATE Dashboard ── */}
      {user.role === 'CANDIDATE' && (
        <>
          <div style={{ display:'flex', gap:12, marginBottom:32, flexWrap:'wrap' }}>
            <Link to="/jobs" className="btn btn-primary">Browse Jobs →</Link>
            <Link to="/resume/upload" className="btn btn-secondary">Upload Resume</Link>
          </div>
          <h2 style={{ marginBottom:20 }}>Your Applications</h2>
          {items.length === 0 ? (
            <div className="empty-state card">
              <div className="empty-icon">📋</div>
              <h3>No applications yet</h3>
              <p>Browse jobs and start applying</p>
              <Link to="/jobs" className="btn btn-primary" style={{marginTop:16}}>Browse Jobs</Link>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
              {items.slice(0, 5).map(app => (
                <div key={app.id} className="card">
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12 }}>
                    <div>
                      <h3 style={{ marginBottom:4 }}>{app.jobTitle}</h3>
                      <p style={{ fontSize:'0.85rem', marginBottom:8 }}>{app.company}</p>
                      <span className={`badge badge-${app.status === 'SHORTLISTED' ? 'success' : app.status === 'REJECTED' ? 'danger' : 'warning'}`}>
                        {app.status}
                      </span>
                    </div>
                    {app.aiScore && (
                      <ScoreBadge score={app.aiScore.matchScore} />
                    )}
                  </div>
                </div>
              ))}
              {items.length > 5 && (
                <Link to="/my-applications" className="btn btn-secondary" style={{alignSelf:'flex-start'}}>
                  View all {items.length} applications →
                </Link>
              )}
            </div>
          )}
        </>
      )}
    </div>
  )
}

function StatCard({ label, value, icon, color }) {
  return (
    <div className="stat-card">
      <div style={{ fontSize:'1.6rem' }}>{icon}</div>
      <div className="stat-value" style={{ background: `linear-gradient(135deg, ${color}, ${color}99)`,
        WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>
        {value}
      </div>
      <div className="stat-label">{label}</div>
    </div>
  )
}

function ScoreBadge({ score }) {
  const color = score >= 70 ? 'var(--success)' : score >= 40 ? 'var(--warning)' : 'var(--danger)'
  return (
    <div style={{ textAlign:'center' }}>
      <div style={{
        width:64, height:64, borderRadius:'50%',
        background:`conic-gradient(${color} ${score * 3.6}deg, rgba(255,255,255,0.05) 0deg)`,
        display:'flex', alignItems:'center', justifyContent:'center',
        position:'relative',
      }}>
        <div style={{
          width:50, height:50, borderRadius:'50%',
          background:'var(--bg-secondary)',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize:'0.85rem', fontWeight:800, color,
        }}>
          {Math.round(score)}%
        </div>
      </div>
      <p style={{ fontSize:'0.7rem', color:'var(--text-muted)', marginTop:4 }}>AI Match</p>
    </div>
  )
}
