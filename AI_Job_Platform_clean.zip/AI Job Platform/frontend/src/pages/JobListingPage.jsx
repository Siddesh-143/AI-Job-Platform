import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { jobsAPI } from '../services/api'
import { useAuth } from '../context/AuthContext'

const JOB_TYPES = ['All', 'FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERNSHIP']

export default function JobListingPage() {
  const { user } = useAuth()
  const [jobs, setJobs]         = useState([])
  const [filtered, setFiltered] = useState([])
  const [loading, setLoading]   = useState(true)
  const [search, setSearch]     = useState('')
  const [typeFilter, setTypeFilter] = useState('All')
  const [searchParams] = useSearchParams()

  useEffect(() => {
    loadJobs()
  }, [])

  useEffect(() => {
    applyFilters()
  }, [jobs, search, typeFilter])

  const loadJobs = async () => {
    try {
      const { data } = await jobsAPI.getAll()
      setJobs(data)
    } catch (e) { console.error(e) }
    finally { setLoading(false) }
  }

  const applyFilters = () => {
    let result = [...jobs]
    if (search.trim()) {
      const q = search.toLowerCase()
      result = result.filter(j =>
        j.title.toLowerCase().includes(q)    ||
        j.company.toLowerCase().includes(q)  ||
        (j.location || '').toLowerCase().includes(q)
      )
    }
    if (typeFilter !== 'All') {
      result = result.filter(j => j.jobType === typeFilter)
    }
    setFiltered(result)
  }

  const handleSearch = async (e) => {
    const val = e.target.value
    setSearch(val)
    if (val.length > 2) {
      try {
        const { data } = await jobsAPI.search(val)
        setFiltered(data)
      } catch {}
    }
  }

  return (
    <div className="page-wrapper animate-in">
      {/* Header */}
      <div style={{ textAlign:'center', marginBottom:40 }}>
        <h1>Find Your <span style={{ background:'var(--gradient-primary)',
          WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>
          Next Opportunity
        </span></h1>
        <p style={{ marginTop:12, fontSize:'1.05rem' }}>
          {jobs.length} jobs available — AI match scores calculated instantly on apply
        </p>
      </div>

      {/* Search bar */}
      <div style={{ marginBottom:24, display:'flex', gap:12, flexWrap:'wrap' }}>
        <input
          type="text"
          placeholder="🔍  Search jobs, companies, locations…"
          value={search}
          onChange={handleSearch}
          style={{ flex:1, minWidth:240 }}
        />
        <div style={{ display:'flex', gap:8 }}>
          {JOB_TYPES.map(t => (
            <button
              key={t}
              className={`btn btn-sm ${typeFilter === t ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setTypeFilter(t)}
            >
              {t === 'FULL_TIME' ? 'Full-time' : t === 'PART_TIME' ? 'Part-time' :
               t === 'CONTRACT' ? 'Contract' : t === 'INTERNSHIP' ? 'Intern' : t}
            </button>
          ))}
        </div>
      </div>

      {/* Results count */}
      {!loading && (
        <p style={{ fontSize:'0.85rem', color:'var(--text-muted)', marginBottom:20 }}>
          Showing {filtered.length} of {jobs.length} jobs
        </p>
      )}

      {/* Job cards */}
      {loading ? (
        <div className="loading-overlay"><div className="spinner" /><p>Loading jobs…</p></div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🔍</div>
          <h3>No jobs found</h3>
          <p>Try adjusting your search or filters</p>
        </div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          {filtered.map((job, i) => (
            <JobCard key={job.id} job={job} index={i} user={user} />
          ))}
        </div>
      )}
    </div>
  )
}

function JobCard({ job, index, user }) {
  const skillList = job.skillsRequired?.split(',').map(s => s.trim()).slice(0, 5) || []

  return (
    <div className="card animate-in" style={{ animationDelay: `${index * 0.05}s` }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:16 }}>
        <div style={{ flex:1 }}>
          {/* Title & Company */}
          <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:8 }}>
            <div style={{
              width:44, height:44, borderRadius:10,
              background:'var(--gradient-primary)', display:'flex',
              alignItems:'center', justifyContent:'center', fontSize:'1.2rem',
              flexShrink:0,
            }}>
              💼
            </div>
            <div>
              <h3 style={{ marginBottom:2 }}>{job.title}</h3>
              <p style={{ fontSize:'0.85rem', color:'var(--text-muted)' }}>
                {job.company} • {job.location || 'Remote'}
              </p>
            </div>
          </div>

          {/* Meta badges */}
          <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:12 }}>
            {job.salaryRange && (
              <span className="badge badge-success">💰 {job.salaryRange}</span>
            )}
            {job.jobType && (
              <span className="badge badge-info">{job.jobType.replace('_', ' ')}</span>
            )}
            {job.experienceYears && (
              <span className="badge badge-purple">⏱ {job.experienceYears}</span>
            )}
            <span className={`badge badge-${job.status === 'OPEN' ? 'success' : 'danger'}`}>
              {job.status}
            </span>
          </div>

          {/* Skills */}
          <div>
            {skillList.map(skill => (
              <span key={skill} className="skill-chip">{skill}</span>
            ))}
            {(job.skillsRequired?.split(',').length || 0) > 5 && (
              <span className="skill-chip">+{job.skillsRequired.split(',').length - 5} more</span>
            )}
          </div>
        </div>

        {/* Action */}
        <div style={{ display:'flex', flexDirection:'column', gap:8, alignItems:'flex-end' }}>
          <Link to={`/jobs/${job.id}`} className="btn btn-primary btn-sm">
            View Details →
          </Link>
          <p style={{ fontSize:'0.75rem', color:'var(--text-muted)' }}>
            {job.applicationCount} applicants
          </p>
        </div>
      </div>
    </div>
  )
}
