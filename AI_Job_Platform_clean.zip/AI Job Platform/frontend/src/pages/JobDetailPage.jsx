import { useEffect, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { jobsAPI, applicationsAPI } from '../services/api'
import { useAuth } from '../context/AuthContext'

export default function JobDetailPage() {
  const { id }      = useParams()
  const { user }    = useAuth()
  const navigate    = useNavigate()

  const [job, setJob]             = useState(null)
  const [loading, setLoading]     = useState(true)
  const [applying, setApplying]   = useState(false)
  const [applied, setApplied]     = useState(false)
  const [coverLetter, setCoverLetter] = useState('')
  const [resumeFile, setResumeFile] = useState(null)
  const [showApply, setShowApply] = useState(false)
  const [error, setError]         = useState('')
  const [success, setSuccess]     = useState('')

  useEffect(() => {
    loadJob()
  }, [id])

  const loadJob = async () => {
    try {
      const { data } = await jobsAPI.getById(id)
      setJob(data)
    } catch { navigate('/jobs') }
    finally { setLoading(false) }
  }

  const handleApply = async () => {
    if (!user) { navigate('/login'); return }
    setApplying(true)
    setError('')
    try {
      await applicationsAPI.apply(id, coverLetter, resumeFile)
      setApplied(true)
      setShowApply(false)
      setSuccess('🎉 Application submitted! AI analysis in progress…')
    } catch (e) {
      setError(e.response?.data?.message || 'Application failed')
    } finally { setApplying(false) }
  }

  if (loading) return (
    <div className="page-wrapper">
      <div className="loading-overlay"><div className="spinner" /><p>Loading job…</p></div>
    </div>
  )

  if (!job) return null

  const skills = job.skillsRequired?.split(',').map(s => s.trim()) || []

  return (
    <div className="page-wrapper animate-in">
      {/* Breadcrumb */}
      <div style={{ marginBottom:24, fontSize:'0.85rem', color:'var(--text-muted)' }}>
        <Link to="/jobs">← Back to Jobs</Link>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 320px', gap:28, alignItems:'start' }}>
        {/* Main content */}
        <div>
          {/* Job header card */}
          <div className="card" style={{ marginBottom:24 }}>
            <div style={{ display:'flex', gap:16, alignItems:'flex-start', marginBottom:20 }}>
              <div style={{
                width:56, height:56, borderRadius:14, background:'var(--gradient-primary)',
                display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.6rem',
                flexShrink:0,
              }}>💼</div>
              <div>
                <h1 style={{ fontSize:'1.6rem', marginBottom:6 }}>{job.title}</h1>
                <p style={{ marginBottom:10 }}>{job.company}</p>
                <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                  {job.location && <span className="badge badge-purple">📍 {job.location}</span>}
                  {job.salaryRange && <span className="badge badge-success">💰 {job.salaryRange}</span>}
                  {job.jobType && <span className="badge badge-info">{job.jobType.replace('_',' ')}</span>}
                  {job.experienceYears && <span className="badge badge-warning">⏱ {job.experienceYears}</span>}
                  <span className={`badge badge-${job.status === 'OPEN' ? 'success' : 'danger'}`}>{job.status}</span>
                </div>
              </div>
            </div>

            {/* Posted by */}
            <p style={{ fontSize:'0.8rem', color:'var(--text-muted)' }}>
              Posted by {job.recruiterName} • {job.applicationCount} applicants
            </p>
          </div>

          {/* Description */}
          <div className="card" style={{ marginBottom:24 }}>
            <h2 style={{ fontSize:'1.1rem', marginBottom:16 }}>Job Description</h2>
            <p style={{ whiteSpace:'pre-wrap', lineHeight:1.8 }}>{job.description}</p>
          </div>

          {/* Skills */}
          <div className="card">
            <h2 style={{ fontSize:'1.1rem', marginBottom:16 }}>Required Skills</h2>
            <div>
              {skills.map(skill => (
                <span key={skill} className="skill-chip">{skill}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar — Apply card */}
        <div>
          <div className="card" style={{ position:'sticky', top:80 }}>
            <h3 style={{ marginBottom:16 }}>Apply for this Role</h3>

            {success && <div className="alert alert-success">{success}</div>}
            {error   && <div className="alert alert-error">{error}</div>}

            {!user && (
              <div>
                <p style={{ marginBottom:16, fontSize:'0.9rem' }}>Sign in to apply and get your AI match score instantly.</p>
                <Link to="/login" className="btn btn-primary w-full" style={{justifyContent:'center'}}>
                  Sign In to Apply
                </Link>
              </div>
            )}

            {user?.role === 'CANDIDATE' && !applied && !showApply && (
              <>
                <div className="alert alert-info" style={{ fontSize:'0.85rem', marginBottom:16 }}>
                  🤖 We'll analyse your resume and show you an AI match score after you apply.
                </div>
                <button
                  className="btn btn-primary w-full"
                  onClick={() => setShowApply(true)}
                  disabled={job.status !== 'OPEN'}
                  style={{justifyContent:'center'}}
                >
                  {job.status === 'OPEN' ? 'Apply Now' : 'Position Closed'}
                </button>
              </>
            )}

            {user?.role === 'CANDIDATE' && showApply && (
              <div>
                <div className="form-group">
                  <label htmlFor="coverLetter">Cover Letter (optional)</label>
                  <textarea
                    id="coverLetter"
                    placeholder="Tell the recruiter why you're a great fit…"
                    value={coverLetter}
                    onChange={e => setCoverLetter(e.target.value)}
                    rows={5}
                  />
                </div>
                <div className="form-group" style={{ marginTop: 12 }}>
                  <label htmlFor="resumeFile">Specific Resume for this Role (PDF)</label>
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: 8 }}>
                    Leave blank to use your default profile resume.
                  </p>
                  <input
                    type="file"
                    id="resumeFile"
                    accept="application/pdf"
                    onChange={e => setResumeFile(e.target.files[0])}
                    className="input"
                    style={{ padding: '8px' }}
                  />
                </div>
                <div style={{ display:'flex', gap:10, marginTop: 16 }}>
                  <button
                    className="btn btn-primary"
                    onClick={handleApply}
                    disabled={applying}
                    style={{flex:1, justifyContent:'center'}}
                  >
                    {applying ? 'Submitting…' : 'Submit Application'}
                  </button>
                  <button className="btn btn-secondary" onClick={() => setShowApply(false)}>
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {applied && (
              <div className="alert alert-success">
                ✅ Applied! Check your <Link to="/my-applications">applications</Link> for the AI score.
              </div>
            )}

            {user?.role === 'RECRUITER' && (
              <div>
                <Link to={`/applicants/${job.id}`} className="btn btn-primary w-full" style={{justifyContent:'center', display:'flex'}}>
                  View Applicants ({job.applicationCount})
                </Link>
                <Link to={`/edit-job/${job.id}`} className="btn btn-secondary w-full" style={{justifyContent:'center', display:'flex', marginTop:10}}>
                  Edit Job
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
