import { useEffect, useState } from 'react'
import { adminAPI } from '../services/api'

export default function AdminPanel() {
  const [users, setUsers]         = useState([])
  const [analytics, setAnalytics] = useState(null)
  const [loading, setLoading]     = useState(true)
  const [tab, setTab]             = useState('analytics')
  const [search, setSearch]       = useState('')

  useEffect(() => {
    Promise.all([adminAPI.getUsers(), adminAPI.getAnalytics()])
      .then(([uRes, aRes]) => { setUsers(uRes.data); setAnalytics(aRes.data) })
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  const toggleBlock = async (id) => {
    try {
      const { data } = await adminAPI.toggleBlock(id)
      setUsers(prev => prev.map(u => u.id === id ? { ...u, isActive: data.isActive } : u))
    } catch { alert('Failed to update user') }
  }

  const deleteUser = async (id) => {
    if (!window.confirm('Delete this user permanently?')) return
    try {
      await adminAPI.deleteUser(id)
      setUsers(prev => prev.filter(u => u.id !== id))
    } catch { alert('Failed to delete user') }
  }

  const filtered = users.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) return (
    <div className="page-wrapper">
      <div className="loading-overlay"><div className="spinner" /><p>Loading admin panel…</p></div>
    </div>
  )

  const roleColor = { ADMIN:'danger', RECRUITER:'info', CANDIDATE:'success' }

  return (
    <div className="page-wrapper animate-in">
      <h1 style={{ marginBottom:8 }}>Admin Panel</h1>
      <p style={{ marginBottom:28 }}>System management and analytics</p>

      {/* Tabs */}
      <div style={{ display:'flex', gap:4, marginBottom:28, borderBottom:'1px solid var(--border)', paddingBottom:0 }}>
        {[['analytics','📊 Analytics'], ['users','👥 Users']].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`btn btn-sm ${tab === key ? 'btn-primary' : 'btn-secondary'}`}
            style={{ borderRadius:'var(--radius-md) var(--radius-md) 0 0', borderBottom:'none' }}
          >
            {label}
          </button>
        ))}
      </div>

      {/* ── Analytics tab ── */}
      {tab === 'analytics' && analytics && (
        <div className="animate-fade">
          <div className="grid-4" style={{ marginBottom:24 }}>
            <BigStat label="Total Users"    value={analytics.totalUsers}    icon="👥" />
            <BigStat label="Recruiters"     value={analytics.totalRecruiters} icon="🏢" />
            <BigStat label="Candidates"     value={analytics.totalCandidates} icon="👤" />
            <BigStat label="Total Jobs"     value={analytics.totalJobs}     icon="💼" />
          </div>
          <div className="grid-3">
            <BigStat label="Open Jobs"        value={analytics.openJobs}               icon="🟢" color="var(--success)" />
            <BigStat label="Total Applications" value={analytics.totalApplications}    icon="📋" color="var(--accent-1)" />
            <BigStat label="Shortlisted"       value={analytics.shortlistedApplications} icon="⭐" color="var(--warning)" />
          </div>

          <div className="grid-3" style={{ marginTop:24 }}>
            <div className="card">
              <h3 style={{ marginBottom:14, fontSize:'0.95rem' }}>Application Status</h3>
              {[
                ['Pending',     analytics.pendingApplications,     'var(--warning)'],
                ['Shortlisted', analytics.shortlistedApplications, 'var(--success)'],
                ['Rejected',    analytics.rejectedApplications,    'var(--danger)'],
              ].map(([label, val, color]) => {
                const total = analytics.totalApplications || 1
                const pct   = Math.round((val / total) * 100)
                return (
                  <div key={label} style={{ marginBottom:12 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.82rem', marginBottom:4 }}>
                      <span style={{ color:'var(--text-secondary)' }}>{label}</span>
                      <span style={{ color, fontWeight:600 }}>{val} ({pct}%)</span>
                    </div>
                    <div style={{ height:6, background:'rgba(255,255,255,0.06)', borderRadius:3 }}>
                      <div style={{ height:'100%', borderRadius:3, background:color, width:`${pct}%`, transition:'width 0.6s ease' }} />
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="card">
              <h3 style={{ marginBottom:14, fontSize:'0.95rem' }}>Job Status</h3>
              {[
                ['Open Jobs',   analytics.openJobs,   'var(--success)'],
                ['Closed Jobs', analytics.closedJobs, 'var(--danger)'],
              ].map(([label, val, color]) => {
                const total = analytics.totalJobs || 1
                const pct   = Math.round((val / total) * 100)
                return (
                  <div key={label} style={{ marginBottom:12 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.82rem', marginBottom:4 }}>
                      <span style={{ color:'var(--text-secondary)' }}>{label}</span>
                      <span style={{ color, fontWeight:600 }}>{val} ({pct}%)</span>
                    </div>
                    <div style={{ height:6, background:'rgba(255,255,255,0.06)', borderRadius:3 }}>
                      <div style={{ height:'100%', borderRadius:3, background:color, width:`${pct}%`, transition:'width 0.6s ease' }} />
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="card">
              <h3 style={{ marginBottom:14, fontSize:'0.95rem' }}>User Breakdown</h3>
              {[
                ['Admins',      1,                            'var(--danger)'],
                ['Recruiters',  analytics.totalRecruiters,    'var(--info)'],
                ['Candidates',  analytics.totalCandidates,    'var(--success)'],
              ].map(([label, val, color]) => {
                const total = analytics.totalUsers || 1
                const pct   = Math.round((val / total) * 100)
                return (
                  <div key={label} style={{ marginBottom:12 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.82rem', marginBottom:4 }}>
                      <span style={{ color:'var(--text-secondary)' }}>{label}</span>
                      <span style={{ color, fontWeight:600 }}>{val} ({pct}%)</span>
                    </div>
                    <div style={{ height:6, background:'rgba(255,255,255,0.06)', borderRadius:3 }}>
                      <div style={{ height:'100%', borderRadius:3, background:color, width:`${pct}%`, transition:'width 0.6s ease' }} />
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── Users tab ── */}
      {tab === 'users' && (
        <div className="animate-fade">
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
            <p>{filtered.length} users</p>
            <input
              placeholder="Search users…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ width:260 }}
            />
          </div>
          <div className="table-wrapper card" style={{ padding:0 }}>
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Name</th><th>Email</th><th>Role</th>
                  <th>Status</th><th>Joined</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(u => (
                  <tr key={u.id}>
                    <td style={{color:'var(--text-muted)'}}>{u.id}</td>
                    <td style={{color:'var(--text-primary)', fontWeight:500}}>{u.name}</td>
                    <td>{u.email}</td>
                    <td><span className={`badge badge-${roleColor[u.role]}`}>{u.role}</span></td>
                    <td>
                      <span className={`badge badge-${u.isActive ? 'success' : 'danger'}`}>
                        {u.isActive ? 'Active' : 'Blocked'}
                      </span>
                    </td>
                    <td>{new Date(u.createdAt).toLocaleDateString()}</td>
                    <td>
                      <div style={{ display:'flex', gap:8 }}>
                        <button
                          className={`btn btn-sm ${u.isActive ? 'btn-secondary' : 'btn-primary'}`}
                          onClick={() => toggleBlock(u.id)}
                        >
                          {u.isActive ? 'Block' : 'Unblock'}
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => deleteUser(u.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}

function BigStat({ label, value, icon, color = 'var(--accent-1)' }) {
  return (
    <div className="stat-card">
      <div style={{ fontSize:'1.5rem' }}>{icon}</div>
      <div className="stat-value" style={{
        background:`linear-gradient(135deg, ${color}, ${color}88)`,
        WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text'
      }}>
        {value}
      </div>
      <div className="stat-label">{label}</div>
    </div>
  )
}
