import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { authAPI } from '../services/api'
import './AuthPages.css'

export default function SignupPage() {
  const [form, setForm]       = useState({ name: '', email: '', password: '', role: 'CANDIDATE' })
  const [error, setError]     = useState('')
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate  = useNavigate()

  const handleChange = (e) =>
    setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters')
      return
    }
    setLoading(true)
    try {
      const { data } = await authAPI.register(form)
      login(data.token, { id: data.id, name: data.name, email: data.email, role: data.role })
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page">
      {/* Left panel */}
      <div className="auth-hero">
        <div className="auth-hero-content">
          <div className="hero-badge">✨ Join SmartHire</div>
          <h1 className="hero-title">Start your<br/><span className="gradient-text">AI-powered</span><br/>journey today</h1>
          <p className="hero-sub">
            Whether you're hiring top talent or looking for your next opportunity,
            SmartHire's AI gives you the edge.
          </p>
          <div className="feature-list">
            <div className="feature-item">✅ AI resume match scoring</div>
            <div className="feature-item">✅ Real-time application tracking</div>
            <div className="feature-item">✅ Skill gap analysis &amp; suggestions</div>
            <div className="feature-item">✅ Role-based dashboards</div>
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="auth-form-panel">
        <div className="auth-form-card animate-in">
          <div className="auth-form-header">
            <Link to="/" className="navbar-logo" style={{marginBottom:'8px', display:'inline-flex'}}>
              <span className="logo-icon">⚡</span>
              <span className="logo-text">Smart<span className="logo-accent">Hire</span></span>
            </Link>
            <h2>Create your account</h2>
            <p>Join thousands of professionals on SmartHire</p>
          </div>

          {error && <div className="alert alert-error">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <input
                id="name" name="name" type="text"
                placeholder="John Doe"
                value={form.name} onChange={handleChange} required
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <input
                id="email" name="email" type="email"
                placeholder="you@example.com"
                value={form.email} onChange={handleChange} required
              />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input
                id="password" name="password" type="password"
                placeholder="Min. 6 characters"
                value={form.password} onChange={handleChange} required
              />
            </div>
            <div className="form-group">
              <label htmlFor="role">I am a …</label>
              <select id="role" name="role" value={form.role} onChange={handleChange}>
                <option value="CANDIDATE">Candidate — looking for jobs</option>
                <option value="RECRUITER">Recruiter — hiring talent</option>
              </select>
            </div>
            <button type="submit" className="btn btn-primary btn-lg w-full" disabled={loading}>
              {loading ? 'Creating account…' : 'Create Account →'}
            </button>
          </form>

          <p className="auth-switch">
            Already have an account? <Link to="/login">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
