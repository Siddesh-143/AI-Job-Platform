import { useState, useRef } from 'react'
import { resumesAPI } from '../services/api'

export default function ResumeUploadPage() {
  const [file, setFile]         = useState(null)
  const [dragging, setDragging] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [result, setResult]     = useState(null)
  const [error, setError]       = useState('')
  const fileInputRef = useRef()

  const handleFile = (f) => {
    if (f && f.type === 'application/pdf') {
      setFile(f)
      setError('')
      setResult(null)
    } else {
      setError('Only PDF files are accepted')
    }
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setDragging(false)
    const f = e.dataTransfer.files[0]
    handleFile(f)
  }

  const handleUpload = async () => {
    if (!file) return
    setUploading(true)
    setError('')
    try {
      const formData = new FormData()
      formData.append('file', file)
      const { data } = await resumesAPI.upload(formData)
      setResult(data)
    } catch (e) {
      setError(e.response?.data?.message || 'Upload failed. Please try again.')
    } finally { setUploading(false) }
  }

  return (
    <div className="page-wrapper animate-in">
      <div style={{ maxWidth:640, margin:'0 auto' }}>
        <h1 style={{ marginBottom:8 }}>Resume Upload</h1>
        <p style={{ marginBottom:32 }}>
          Upload your PDF resume. Our AI will extract your skills and automatically
          score your applications against job descriptions.
        </p>

        {error   && <div className="alert alert-error">{error}</div>}
        {result  && (
          <div className="alert alert-success">
            ✅ <strong>Resume uploaded successfully!</strong><br />
            File: {result.fileName} &nbsp;•&nbsp; Text extracted: {result.hasText ? 'Yes ✓' : 'No — try a text-based PDF'}
          </div>
        )}

        {/* Drop zone */}
        <div
          className="card"
          style={{
            border: `2px dashed ${dragging ? 'var(--accent-1)' : file ? 'var(--accent-2)' : 'var(--border)'}`,
            background: dragging ? 'rgba(108,99,255,0.08)' : file ? 'rgba(6,214,160,0.05)' : 'var(--bg-card)',
            textAlign:'center', padding:'48px 32px', cursor:'pointer',
            transition:'var(--transition)', marginBottom:24,
          }}
          onDragOver={e => { e.preventDefault(); setDragging(true) }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current.click()}
        >
          <div style={{ fontSize:'3rem', marginBottom:12 }}>
            {file ? '📄' : '☁️'}
          </div>

          {file ? (
            <>
              <h3 style={{ color:'var(--accent-2)', marginBottom:6 }}>{file.name}</h3>
              <p style={{ fontSize:'0.85rem' }}>
                {(file.size / 1024).toFixed(1)} KB • Click to change
              </p>
            </>
          ) : (
            <>
              <h3 style={{ marginBottom:8 }}>Drop your PDF here</h3>
              <p style={{ fontSize:'0.88rem' }}>or click to browse • PDF only • Max 10MB</p>
            </>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="application/pdf"
            style={{ display:'none' }}
            onChange={e => handleFile(e.target.files[0])}
          />
        </div>

        <button
          className="btn btn-primary btn-lg w-full"
          onClick={handleUpload}
          disabled={!file || uploading}
          style={{ justifyContent:'center' }}
        >
          {uploading ? (
            <>Uploading &amp; Analysing… <span style={{marginLeft:8}}>🤖</span></>
          ) : (
            'Upload &amp; Analyse with AI →'
          )}
        </button>

        {/* Info section */}
        <div className="card" style={{ marginTop:28 }}>
          <h3 style={{ marginBottom:16 }}>🤖 What happens after upload?</h3>
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            {[
              ['1️⃣', 'Text Extraction',   'Our AI reads every page of your PDF and extracts clean text'],
              ['2️⃣', 'Skill Detection',    'spaCy NLP identifies your technical skills and experience'],
              ['3️⃣', 'Auto-Scoring',       'When you apply, we instantly compare your skills to the JD'],
              ['4️⃣', 'Gap Analysis',       'We tell you exactly which skills are missing and how to improve'],
            ].map(([icon, title, desc]) => (
              <div key={title} style={{ display:'flex', gap:14, alignItems:'flex-start' }}>
                <span style={{ fontSize:'1.3rem' }}>{icon}</span>
                <div>
                  <strong style={{ fontSize:'0.9rem', display:'block', marginBottom:2 }}>{title}</strong>
                  <p style={{ fontSize:'0.85rem' }}>{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
