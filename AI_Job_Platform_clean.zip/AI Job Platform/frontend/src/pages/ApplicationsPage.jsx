import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { applicationsAPI } from '../services/api'

export default function ApplicationsPage() {
  const [apps, setApps]       = useState([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState(null)

  useEffect(() => {
    applicationsAPI.getMyApps()
      .then(r => setApps(r.data))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  if (loading) return (
    <div className="page-wrapper">
      <div className="loading-overlay"><div className="spinner" /><p>Loading applications…</p></div>
    </div>
  )

  const statusBadge = (s) => {
    const map = { PENDING:'warning', SHORTLISTED:'success', REJECTED:'danger' }
    return <span className={`badge badge-${map[s]}`}>{s}</span>
  }

  return (
    <div className="page-wrapper animate-in">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:32 }}>
        <div>
          <h1>My Applications</h1>
          <p style={{ marginTop:6 }}>{apps.length} applications submitted</p>
        </div>
        <Link to="/jobs" className="btn btn-primary">Browse More Jobs</Link>
      </div>

      {apps.length === 0 ? (
        <div className="empty-state card">
          <div className="empty-icon">📋</div>
          <h3>No applications yet</h3>
          <p>Start applying for jobs to see your applications here</p>
          <Link to="/jobs" className="btn btn-primary" style={{marginTop:16}}>Browse Jobs</Link>
        </div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          {apps.map(app => (
            <div key={app.id} className="card animate-in">
              {/* Summary row */}
              <div
                style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start',
                  flexWrap:'wrap', gap:12, cursor:'pointer' }}
                onClick={() => setExpanded(expanded === app.id ? null : app.id)}
              >
                <div style={{ flex:1 }}>
                  <h3 style={{ marginBottom:4 }}>{app.jobTitle}</h3>
                  <p style={{ fontSize:'0.85rem', marginBottom:10 }}>{app.company}</p>
                  <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                    {statusBadge(app.status)}
                    <span style={{ fontSize:'0.78rem', color:'var(--text-muted)' }}>
                      Applied {new Date(app.appliedAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {/* AI Score ring */}
                {app.aiScore ? (
                  <ScoreRing score={app.aiScore.matchScore} />
                ) : (
                  <div style={{ textAlign:'center', minWidth:70 }}>
                    <div style={{ fontSize:'1.5rem' }}>⏳</div>
                    <p style={{ fontSize:'0.7rem', color:'var(--text-muted)' }}>Analysing…</p>
                  </div>
                )}
              </div>

              {/* Expanded AI details */}
              {expanded === app.id && app.aiScore && (
                <div style={{ marginTop:20, borderTop:'1px solid var(--border)', paddingTop:20 }}
                     className="animate-fade">
                  <h4 style={{ marginBottom:14, color:'var(--text-secondary)' }}>🤖 AI Resume Analysis</h4>

                  <div className="grid-2" style={{ gap:16 }}>
                    {/* Matched skills */}
                    <div>
                      <p style={{ fontSize:'0.78rem', fontWeight:700, textTransform:'uppercase',
                        letterSpacing:'0.06em', color:'var(--success)', marginBottom:8 }}>
                        ✅ Matched Skills ({app.aiScore.matchedSkills?.length || 0})
                      </p>
                      <div>
                        {app.aiScore.matchedSkills?.map(s => (
                          <span key={s} className="skill-chip matched">{s}</span>
                        ))}
                      </div>
                    </div>

                    {/* Missing skills */}
                    <div>
                      <p style={{ fontSize:'0.78rem', fontWeight:700, textTransform:'uppercase',
                        letterSpacing:'0.06em', color:'var(--danger)', marginBottom:8 }}>
                        ❌ Missing Skills ({app.aiScore.missingSkills?.length || 0})
                      </p>
                      <div>
                        {app.aiScore.missingSkills?.map(s => (
                          <span key={s} className="skill-chip missing">{s}</span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Suggestions */}
                  {app.aiScore.suggestions?.length > 0 && (
                    <div style={{ marginTop:16 }}>
                      <p style={{ fontSize:'0.78rem', fontWeight:700, textTransform:'uppercase',
                        letterSpacing:'0.06em', color:'var(--warning)', marginBottom:10 }}>
                        💡 Improvement Suggestions
                      </p>
                      <ul style={{ listStyle:'none', display:'flex', flexDirection:'column', gap:8 }}>
                        {app.aiScore.suggestions.map((s, i) => (
                          <li key={i} style={{ display:'flex', gap:10, alignItems:'flex-start',
                            fontSize:'0.88rem', color:'var(--text-secondary)' }}>
                            <span style={{ color:'var(--warning)', flexShrink:0 }}>→</span> {s}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}

              {expanded !== app.id && (
                <p style={{ fontSize:'0.78rem', color:'var(--text-muted)', marginTop:12 }}>
                  {app.aiScore ? 'Click to see AI analysis details ▼' : ''}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function ScoreRing({ score }) {
  const color = score >= 70 ? 'var(--success)' : score >= 40 ? 'var(--warning)' : 'var(--danger)'
  const deg   = score * 3.6

  return (
    <div style={{ textAlign:'center', minWidth:80 }}>
      <div style={{
        width:72, height:72, borderRadius:'50%',
        background:`conic-gradient(${color} ${deg}deg, rgba(255,255,255,0.06) 0deg)`,
        display:'flex', alignItems:'center', justifyContent:'center',
        margin:'0 auto',
      }}>
        <div style={{
          width:56, height:56, borderRadius:'50%',
          background:'var(--bg-secondary)',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontFamily:'var(--font-display)',
          fontSize:'1rem', fontWeight:800, color,
        }}>
          {Math.round(score)}%
        </div>
      </div>
      <p style={{ fontSize:'0.7rem', color:'var(--text-muted)', marginTop:6 }}>AI Match</p>
    </div>
  )
}
