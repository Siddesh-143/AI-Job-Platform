import axios from 'axios'

// Base axios instance — all API calls go through this
const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
})

// ── Request interceptor: attach JWT ─────────────────────────
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// ── Response interceptor: handle 401 auto-logout ────────────
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// ── Auth ─────────────────────────────────────────────────────
export const authAPI = {
  login:    (data) => api.post('/auth/login', data),
  register: (data) => api.post('/auth/register', data),
  me:       ()     => api.get('/auth/me'),
}

// ── Jobs ─────────────────────────────────────────────────────
export const jobsAPI = {
  getAll:          ()          => api.get('/jobs'),
  getAllAdmin:      ()          => api.get('/jobs/all'),
  getById:         (id)        => api.get(`/jobs/${id}`),
  search:          (keyword)   => api.get(`/jobs/search?keyword=${keyword}`),
  getMyJobs:       (id)        => api.get(`/jobs/recruiter/${id}`),
  create:          (data)      => api.post('/jobs', data),
  update:          (id, data)  => api.put(`/jobs/${id}`, data),
  delete:          (id)        => api.delete(`/jobs/${id}`),
}

// ── Applications ─────────────────────────────────────────────
export const applicationsAPI = {
  apply:          (jobId, coverLetter, resumeFile) => {
    const formData = new FormData()
    if (coverLetter) formData.append('coverLetter', coverLetter)
    if (resumeFile) formData.append('resumeFile', resumeFile)
    return api.post(`/applications/apply/${jobId}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
  },
  getMyApps:      ()        => api.get('/applications/my-applications'),
  getForJob:      (jobId)   => api.get(`/applications/job/${jobId}`),
  updateStatus:   (id, status) => api.put(`/applications/${id}/status`, { status }),
}

// ── Resumes ──────────────────────────────────────────────────
export const resumesAPI = {
  upload:         (formData) =>
    api.post('/resumes/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
  getMyResume:    ()         => api.get('/resumes/my-resume'),
  getByCandidate: (id)       => api.get(`/resumes/${id}`),
}

// ── Admin ────────────────────────────────────────────────────
export const adminAPI = {
  getUsers:     ()   => api.get('/admin/users'),
  toggleBlock:  (id) => api.put(`/admin/users/${id}/block`),
  deleteUser:   (id) => api.delete(`/admin/users/${id}`),
  getAnalytics: ()   => api.get('/admin/analytics'),
}

export default api
