import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import './Navbar.css'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [menuOpen, setMenuOpen] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + '/')

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        {/* Logo */}
        <Link to="/" className="navbar-logo">
          <span className="logo-icon">⚡</span>
          <span className="logo-text">Smart<span className="logo-accent">Hire</span></span>
        </Link>

        {/* Desktop nav links */}
        <div className="navbar-links">
          <Link to="/jobs" className={`nav-link ${isActive('/jobs') ? 'active' : ''}`}>
            Browse Jobs
          </Link>

          {user?.role === 'CANDIDATE' && (
            <>
              <Link to="/my-applications" className={`nav-link ${isActive('/my-applications') ? 'active' : ''}`}>
                My Applications
              </Link>
              <Link to="/resume/upload" className={`nav-link ${isActive('/resume/upload') ? 'active' : ''}`}>
                Resume
              </Link>
            </>
          )}

          {user?.role === 'RECRUITER' && (
            <>
              <Link to="/post-job" className={`nav-link ${isActive('/post-job') ? 'active' : ''}`}>
                Post a Job
              </Link>
              <Link to="/dashboard" className={`nav-link ${isActive('/dashboard') ? 'active' : ''}`}>
                Dashboard
              </Link>
            </>
          )}

          {user?.role === 'ADMIN' && (
            <Link to="/admin" className={`nav-link ${isActive('/admin') ? 'active' : ''}`}>
              Admin Panel
            </Link>
          )}
        </div>

        {/* Auth area */}
        <div className="navbar-auth">
          {user ? (
            <div className="user-menu">
              <div className="user-avatar" onClick={() => setMenuOpen(!menuOpen)}>
                <span>{user.name?.charAt(0).toUpperCase()}</span>
              </div>
              {menuOpen && (
                <div className="user-dropdown">
                  <div className="dropdown-header">
                    <strong>{user.name}</strong>
                    <span className={`badge badge-${user.role === 'ADMIN' ? 'danger' : user.role === 'RECRUITER' ? 'info' : 'success'}`}>
                      {user.role}
                    </span>
                  </div>
                  <div className="dropdown-divider" />
                  <Link to="/dashboard" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    Dashboard
                  </Link>
                  <button className="dropdown-item danger" onClick={handleLogout}>
                    Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              <Link to="/login"  className="btn btn-secondary btn-sm">Login</Link>
              <Link to="/signup" className="btn btn-primary btn-sm">Sign Up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  )
}
